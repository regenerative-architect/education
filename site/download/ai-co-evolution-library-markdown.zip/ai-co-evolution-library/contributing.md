# 🤝 Contributing to AI Co-Evolution in Education

**Thank you for your interest in co-creating the future of education!**

*Path:* `CONTRIBUTING.md` *Repository:* planetaryrestorationarchive/education

---

## 📋 Table of Contents

**Click to expand navigation**

-   [🌟 Welcome, Co-Creator](contributing.md#-welcome-co-creator)
-   [🎯 Ways to Contribute](contributing.md#-ways-to-contribute)
-   [🚀 Getting Started](contributing.md#-getting-started)
-   [📝 Contribution Types](contributing.md#-contribution-types)
-   [🛠️ Development Guidelines](contributing.md#️-development-guidelines)
-   [📖 Content Guidelines](contributing.md#-content-guidelines)
-   [🤝 Community Guidelines](contributing.md#-community-guidelines)
-   [📞 Support & Questions](contributing.md#-support--questions)
-   [🏆 Recognition](contributing.md#-recognition)

---

## 🌟 Welcome, Co-Creator

> [!IMPORTANT]
> 
> **This isn't just another open-source project.** **This is a living collaboration to reimagine how humans and AI learn together.**

We believe every educator, student, researcher, and technologist has wisdom to contribute to this sacred work. Whether you're sharing a lesson plan, fixing a typo, or proposing a major architectural change, your contribution helps shape the future of conscious education.

---

## 🎯 Ways to Contribute

| 🌿 Educators | 🌀 Students | 🛠️ Developers | 🔬 Researchers |
| --- | --- | --- | --- |
| • Share lesson plans  <br>• Document classroom experiences  <br>• Provide teacher feedback  <br>• Lead pilot programs  <br>• Mentor new contributors | • Share learning experiences  <br>• Test educational content  <br>• Provide youth perspectives  <br>• Create student resources  <br>• Lead peer feedback sessions | • Fix bugs and issues  <br>• Improve documentation  <br>• Add new features  <br>• Enhance accessibility  <br>• Optimize performance | • Share research findings  <br>• Contribute data analysis  <br>• Validate educational approaches  <br>• Design impact studies  <br>• Connect academic insights |

---

## 🚀 Getting Started

### 📱 Quick Contributions (No Code Required)

**💬 Join the Conversation**

**GitHub Discussions:**

-   💭 Share Ideas
-   ❓ Ask Questions
-   📖 Share Stories

**Community Spaces:**

-   💬 Discord Community
-   📧 [Monthly Newsletter](https://planetaryrestorationarchive.com)
-   🗓️ Office Hours (Fridays 4-5 PM EST)

**🐛 Report Issues**

Found a problem? Help us fix it!

**Before creating an issue:**

1.  🔍 Search existing issues to avoid duplicates
2.  📝 Use our issue templates for clarity
3.  🎯 Be specific about the problem and context

**Issue Types:**

-   🐛 Bug Report
-   ✨ Feature Request
-   📚 Content Suggestion
-   🎓 Educator Feedback

### 🛠️ Code & Content Contributions

**📋 Step-by-Step Process**

1.  **🍴 Fork the Repository**
    
    ```bash
    # Click "Fork" button on GitHub or:
    gh repo fork planetaryrestorationarchive/education
    ```
    
2.  **📥 Clone Your Fork**
    
    ```bash
    git clone https://github.com/YOUR-USERNAME/education.git
    cd education
    ```
    
3.  **🌿 Create a Branch**
    
    ```bash
    # Use descriptive branch names:
    git checkout -b feature/lesson-plan-climate-science
    git checkout -ب fix/broken-link-in-onboarding
    git checkout -b docs/update-contribution-guide
    ```
    
4.  **✨ Make Your Changes**
    
    -   Follow our [content guidelines](contributing.md#-content-guidelines)
    -   Test any code changes locally
    -   Update documentation as needed
5.  **📝 Commit Your Work**
    
    ```bash
    git add .
    git commit -m "Add: Climate science lesson plan for grade 6-8"
    
    # Follow conventional commit format:
    # Add: New feature or content
    # Fix: Bug fixes
    # Update: Improvements to existing content
    # Docs: Documentation changes
    ```
    
6.  **🚀 Push and Create Pull Request**
    
    ```bash
    git push origin your-branch-name
    # Then create PR through GitHub interface
    ```

---

## 📝 Contribution Types

### 🎓 Educational Content

**📚 Lesson Plans**

**Location:** `classroom-tools/lesson-plans/`

**Requirements:**

-   ✅ Age-appropriate content (specify grade levels)
-   ✅ Clear learning objectives
-   ✅ Ethical AI integration guidelines
-   ✅ Assessment criteria
-   ✅ Reflection prompts
-   ✅ Tested in real classroom (preferred)

**Template:** Use our lesson plan template

**🎨 Project Templates**

**Location:** `classroom-tools/project-templates/`

**Guidelines:**

-   Scaffold student-AI collaboration
-   Include ethical reasoning components
-   Provide clear rubrics
-   Offer multiple difficulty levels
-   Support diverse learning styles

**🤔 Reflection Prompts**

**Location:** `reflection-journals/`

**Focus Areas:**

-   AI ethics and bias awareness
-   Creative authenticity
-   Emotional safety
-   Critical thinking development
-   Future implications

### 🛠️ Technical Contributions

**📖 Documentation**

**Priorities:**

-   🌍 Accessibility improvements
-   🔗 Fix broken links
-   📱 Mobile-friendly formatting
-   🌐 Multi-language support
-   🎯 Clarity and conciseness

**Style Guide:**

-   Use inclusive language
-   Write for grade 8 reading level when possible
-   Include examples and visuals
-   Test all instructions

**🎨 Design & UX**

**Opportunities:**

-   Visual templates for lesson plans
-   Infographic summaries
-   Interactive educational tools
-   Accessibility enhancements
-   Mobile optimization

### 🔬 Research Contributions

**📊 Data & Studies**

**Welcome Contributions:**

-   Classroom implementation data
-   Student feedback analysis
-   Teacher experience surveys
-   Learning outcome assessments
-   Longitudinal impact studies

**Requirements:**

-   Ethical approval for human subjects research
-   Anonymized data only
-   Clear methodology documentation
-   Reproducible analysis

---

## 🛠️ Development Guidelines

### 📁 File Organization

```
📁 Repository Structure
├── 📁 classroom-tools/
│   ├── 📁 lesson-plans/          # Individual lesson files
│   ├── 📁 project-templates/     # Reusable project frameworks
│   ├── 📁 assessment-rubrics/    # Evaluation criteria
│   └── 📁 reflection-prompts/    # Ethical thinking exercises
├── 📁 teacher-resources/
│   ├── 📄 onboarding-guide.md
│   ├── 📄 ethical-framework.md
│   └── 📄 troubleshooting-guide.md
├── 📁 institutional/
│   ├── 📄 implementation-roadmap.md
│   └── 📁 policy-templates/
└── 📁 community/
    ├── 📄 success-stories.md
    └── 📄 educator-circles.md
```

### 📝 Naming Conventions

-   **Files:** `kebab-case.md` (e.g., `ethical-framework.md`)
-   **Directories:** `kebab-case/` (e.g., `lesson-plans/`)
-   **Branches:** `type/descriptive-name` (e.g., `feature/math-ai-collaboration`)
-   **Commits:** `Type: Brief description` (e.g., `Add: New ethics reflection prompts`)

### 🎨 Markdown Standards

-   Use GitHub-flavored markdown
-   Include table of contents for long documents
-   Add badges and visual elements appropriately
-   Ensure mobile-friendly formatting
-   Test all links and references

---

## 📖 Content Guidelines

### 🎯 Quality Standards

> [!IMPORTANT]
> 
> **All content must align with our [Core Philosophy](welcome-ritual.md) and maintain our Zero Harm commitment.**

**Essential Elements:**

-   ✅ **Educational Value:** Clear learning objectives and outcomes
-   ✅ **Ethical Integration:** Responsible AI use guidelines
-   ✅ **Accessibility:** Inclusive design and multiple formats
-   ✅ **Cultural Sensitivity:** Respectful of diverse perspectives
-   ✅ **Evidence-Based:** Grounded in research and practice

### 🌍 Inclusivity Requirements

-   **Language:** Clear, jargon-free, accessible to non-native speakers
-   **Examples:** Diverse cultural contexts and names
-   **Accessibility:** Alt text for images, descriptive link text
-   **Learning Styles:** Multiple modalities and approaches
-   **Economic Context:** Materials accessible without premium tools

### 🛡️ Ethical Standards

-   **Student Agency:** Always prioritize learner choice and understanding
-   **Transparency:** Clear disclosure of AI involvement
-   **Privacy:** Protect student data and personal information
-   **Bias Awareness:** Actively address AI limitations and biases
-   **Emotional Safety:** Content promotes well-being over performance

---

## 🤝 Community Guidelines

### 💚 Our Values in Action

|     |     |
| --- | --- |
| **🌱 Regenerative Engagement**  <br>• Contribute in ways that energize rather than extract  <br>• Build on others' work respectfully  <br>• Share knowledge generously  <br>• Support newcomers actively | **🔍 Curiosity Over Certainty**  <br>• Ask questions before making assumptions  <br>• Embrace learning from disagreement  <br>• Stay open to new perspectives  <br>• Celebrate "I don't know" moments |
| **🤝 Sacred Partnership**  <br>• Treat every contributor as a valued collaborator  <br>• Acknowledge all forms of contribution  <br>• Build consensus through dialogue  <br>• Honor diverse expertise equally | **👑 Creative Sovereignty**  <br>• Respect others' intellectual contributions  <br>• Encourage original thinking  <br>• Credit all sources appropriately  <br>• Foster authentic expression |

### 🚫 Unacceptable Behavior

We have zero tolerance for:

-   Harassment, discrimination, or hate speech
-   Violation of privacy or confidentiality
-   Plagiarism or misattribution
-   Spam or promotional content unrelated to education
-   Behavior that harms the learning community

**Reporting:** Contact or use GitHub's reporting features.

---

## 📞 Support & Questions

### 🤝 Get Help & Connect

### 🆘 Need Help?

**For Contributors:**

-   💬 **General Questions:** GitHub Discussions
-   🐛 **Technical Issues:** GitHub Issues
-   📞 **Complex Questions:** Office Hours
-   📧 **Private Matters:**

**Response Times:**

-   GitHub Issues/Discussions: Within 48 hours
-   Email: Within 24 hours during business days
-   Discord: Real-time community support

### 📚 Learning Resources

-   🎓 New Contributor Guide
-   📖 Educational Content Standards
-   🛠️ Technical Setup Guide
-   🎯 Impact Measurement

---

## 🏆 Recognition

### 🌟 Contributor Spotlight

We celebrate contributors through:

-   📸 **Monthly Spotlight:** Featured in newsletter and social media
-   🎯 **Expertise Badges:** Recognition for specialized contributions
-   🎪 **Conference Speaking:** Opportunities to share your work
-   📚 **Co-authorship:** Academic papers and case studies
-   🏆 **Annual Awards:** Outstanding contribution recognition

### 📈 Contribution Tracking

**📊 Contributor Levels**

**🌱 Seedling Contributors** *(1-5 contributions)*

-   First-time contributors
-   Learning community norms
-   Exploring different contribution types

**🌿 Growing Contributors** *(6-25 contributions)*

-   Regular community participants
-   Developing expertise areas
-   Mentoring newcomers

**🌳 Established Contributors** *(26-100 contributions)*

-   Recognized domain experts
-   Leading specific initiatives
-   Shaping project direction

**🌲 Elder Contributors** *(100+ contributions)*

-   Long-term community stewards
-   Strategic decision making
-   Legacy project leadership

### 🎉 Acknowledgments

**All contributors are acknowledged in:**

-   Repository README contributor section
-   Annual impact reports
-   Academic publications
-   Conference presentations
-   Community celebrations

---

## 🌍 Join the Movement

**Every contribution, no matter how small, helps shape the future of conscious education.**

*Together, we're not just building tools—we're cultivating wisdom for the age of artificial intelligence.*

---

**Stewarded by:** Foster + Navi • **Planetary Restoration Archive** **License:** Creative Commons Attribution-ShareAlike 4.0 • **Version:** 1.1

**Thank you for being part of this sacred work! 🙏**

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `CONTRIBUTING.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
