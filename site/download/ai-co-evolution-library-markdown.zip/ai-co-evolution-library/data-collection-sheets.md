# 📊 Local Ecosystem Study - Data Collection Sheets

**Version:** 1.0 **Date:** August 2025

---

## 📋 Sheet Collection Overview

This collection provides standardized data collection forms for student ecosystem research projects. All sheets are designed to be:

-   **Print-friendly** (black & white, standard 8.5x11")
-   **Field-durable** (simple layouts, large writing spaces)
-   **AI-collaboration ready** (spaces for verification and analysis notes)
-   **Curriculum-aligned** (supports systems thinking and scientific methodology)

**Included Sheets:**

1.  **Project Setup & Site Information**
2.  **Daily Field Observation Log**
3.  **Species Identification & Abundance Survey**
4.  **Habitat Characteristics Assessment**
5.  **Environmental Variables Measurement**
6.  **Human Impact Assessment**
7.  **Temporal Change Tracking**
8.  **Photo & Sample Documentation Log**
9.  **AI Collaboration Tracking Sheet**
10.  **Weekly Reflection & Analysis**

---

## 📄 Sheet 1: Project Setup & Site Information

**Print Instructions:** Single sheet, front and back recommended

### Project Information

**Student Name(s):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Project Title:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Start Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **End Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Grade Level:** \_\_\_\_\_\_\_ **Class Period:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Study Site Details

**Site Name/Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **GPS Coordinates (if available):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Ecosystem Type:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Site Access Notes:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Safety Considerations:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Research Focus

**Primary Research Question:**

---

**Key Hypotheses:**

**Target Species/Features:**

---

### Equipment Checklist

**Required Equipment:**

-   [ ]  This data collection packet
-   [ ]  Pencils/pens (multiple)
-   [ ]  Camera/phone for photos
-   [ ]  Measuring tape/ruler
-   [ ]  Thermometer
-   [ ]  Watch/timer

**Optional Equipment:**

-   [ ]  Magnifying glass
-   [ ]  pH test strips
-   [ ]  Binoculars
-   [ ]  Collection containers
-   [ ]  Field guides
-   [ ]  Weather app access

### Emergency Information

**Emergency Contact:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Nearest Address:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Cell Service:** \[ \] Good \[ \] Poor \[ \] None **Exit Strategy:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

## 📄 Sheet 2: Daily Field Observation Log

**Print Instructions:** Multiple copies needed - one per field visit

### Session Information

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Day of Week:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Start Time:** \_\_\_\_\_\_\_ **End Time:** \_\_\_\_\_\_\_ **Duration:** \_\_\_\_\_\_\_ **Observer(s):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Site Condition:** \[ \] Excellent \[ \] Good \[ \] Fair \[ \] Poor

### Weather Conditions

**Temperature:** \_\_\_\_\_ °F/°C **Method:** \[ \] Thermometer \[ \] App \[ \] Estimate **Sky:** \[ \] Clear \[ \] Partly Cloudy \[ \] Overcast \[ \] Stormy **Precipitation:** \[ \] None \[ \] Light \[ \] Moderate \[ \] Heavy **Wind:** \[ \] None \[ \] Light Breeze \[ \] Moderate \[ \] Strong **Recent Weather (past 24hrs):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### General Observations

#### First Impressions (before detailed observation)

**Most noticeable features today:**

---

**Changes since last visit:**

---

**Unusual observations:**

---

#### Systematic Observation (spend 10 minutes in each area)

**Area 1 Description:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Species/features observed:**

**Activity level:** \[ \] High \[ \] Moderate \[ \] Low \[ \] None

**Area 2 Description:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Species/features observed:**

**Activity level:** \[ \] High \[ \] Moderate \[ \] Low \[ \] None

**Area 3 Description:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Species/features observed:**

**Activity level:** \[ \] High \[ \] Moderate \[ \] Low \[ \] None

### Questions Raised Today

**What I want to investigate further:**

**AI research prompts to try:**

---

### Quality Check

**Data completeness:** \[ \] Complete \[ \] Mostly complete \[ \] Partial **Photo documentation:** \_\_\_\_\_ photos taken **Additional notes needed:** \[ \] Yes \[ \] No **Follow-up required:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

## 📄 Sheet 3: Species Identification & Abundance Survey

**Print Instructions:** Multiple copies recommended

### Survey Session Details

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Time:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Duration:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Survey Method:** \[ \] Point count \[ \] Transect \[ \] Area search \[ \] Other: \_\_\_\_\_\_\_ **Survey Area Size:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Weather:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Species Observations

| #   | Species Name/Description | Count | Size/Age | Location | Behavior | Photo # |
| --- | --- | --- | --- | --- | --- | --- |
| 1   |     |     |     |     |     |     |
| 2   |     |     |     |     |     |     |
| 3   |     |     |     |     |     |     |
| 4   |     |     |     |     |     |     |
| 5   |     |     |     |     |     |     |
| 6   |     |     |     |     |     |     |
| 7   |     |     |     |     |     |     |
| 8   |     |     |     |     |     |     |
| 9   |     |     |     |     |     |     |
| 10  |     |     |     |     |     |     |

### Species Requiring Further Identification

**Unknown Species #1:** **Physical Description:**

-   Size: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Color/Pattern: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Shape/Form: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Distinguishing features: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Behavior/Habitat:**

-   Where found: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   What doing: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Associated with: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**AI Identification Notes:** **Suggested species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence level:** \_\_\_\_\_\_\_ **Verification needed:** \[ \] Yes \[ \] No

**Unknown Species #2:** **Physical Description:**

-   Size: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Color/Pattern: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Shape/Form: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Distinguishing features: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Behavior/Habitat:**

-   Where found: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   What doing: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Associated with: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**AI Identification Notes:** **Suggested species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence level:** \_\_\_\_\_\_\_ **Verification needed:** \[ \] Yes \[ \] No

### Abundance Summary

**Total species observed:** \_\_\_\_\_\_\_ **Most abundant species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Least abundant species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Species diversity:** \[ \] High \[ \] Medium \[ \] Low

**Dominant life forms:**

-   [ ]  Trees \_\_\_% - \[ \] Shrubs \_\_\_% - \[ \] Grasses \_\_\_% - \[ \] Forbs \_\_\_%
-   [ ]  Birds \_\_\_% - \[ \] Insects \_\_\_% - \[ \] Mammals \_\_\_% - \[ \] Other \_\_\_%

### Ecological Interactions Observed

**Predator-prey relationships:**

---

**Competition (same resources):**

---

**Cooperation/mutualism:**

---

**Pollination/seed dispersal:**

---

## 📄 Sheet 4: Habitat Characteristics Assessment

**Print Instructions:** Complete once per site, update if changes observed

### Physical Environment

#### Topography & Layout

**Elevation:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Slope:** \[ \] Flat \[ \] Gentle \[ \] Moderate \[ \] Steep **Aspect (direction facing):** \[ \] N \[ \] NE \[ \] E \[ \] SE \[ \] S \[ \] SW \[ \] W \[ \] NW **Landform:** \[ \] Valley \[ \] Hillside \[ \] Ridge \[ \] Flat \[ \] Depression \[ \] Other: \_\_\_\_\_\_\_

#### Soil Characteristics

**Soil type:** \[ \] Clay \[ \] Sand \[ \] Silt \[ \] Loam \[ \] Rocky \[ \] Organic \[ \] Mixed **Soil color:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Soil moisture:** \[ \] Dry \[ \] Slightly moist \[ \] Moist \[ \] Wet \[ \] Saturated **Organic matter:** \[ \] High \[ \] Moderate \[ \] Low \[ \] None visible **Soil depth (if measurable):** \_\_\_\_\_\_\_\_\_\_\_\_\_ **pH (if tested):** \_\_\_\_\_\_\_\_\_\_\_\_\_

#### Water Features

**Water present:** \[ \] Yes \[ \] No **If yes, type:** \[ \] Stream \[ \] River \[ \] Pond \[ \] Lake \[ \] Wetland \[ \] Seasonal **Water flow:** \[ \] Still \[ \] Slow \[ \] Moderate \[ \] Fast **Water clarity:** \[ \] Clear \[ \] Slightly cloudy \[ \] Murky \[ \] Very murky **Estimated depth:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Width:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Vegetation Structure

#### Vertical Layers

**Canopy layer:** \[ \] Present \[ \] Absent **Height:** \_\_\_\_\_ **Cover:** \_\_\_\_\_% **Understory layer:** \[ \] Present \[ \] Absent **Height:** \_\_\_\_\_ **Cover:** \_\_\_\_\_% **Shrub layer:** \[ \] Present \[ \] Absent **Height:** \_\_\_\_\_ **Cover:** \_\_\_\_\_% **Herb layer:** \[ \] Present \[ \] Absent **Height:** \_\_\_\_\_ **Cover:** \_\_\_\_\_% **Ground layer:** \[ \] Present \[ \] Absent **Cover:** \_\_\_\_\_%

#### Ground Cover Types

**Dominant ground cover:**

-   [ ]  Grass \_\_\_\_% - \[ \] Leaves/litter \_\_\_\_% - \[ \] Moss \_\_\_\_% - \[ \] Bare soil \_\_\_\_%
-   [ ]  Rock \_\_\_\_% - \[ \] Sand \_\_\_\_% - \[ \] Water \_\_\_\_% - \[ \] Other: \_\_\_\_\_ \_\_\_\_%

#### Dominant Plant Species

**Trees (if present):**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Approx. count:** \_\_\_\_\_\_\_
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Approx. count:** \_\_\_\_\_\_\_
3.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Approx. count:** \_\_\_\_\_\_\_

**Shrubs:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Approx. count:** \_\_\_\_\_\_\_
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Approx. count:** \_\_\_\_\_\_\_

**Herbaceous plants:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Abundance:** \[ \] Rare \[ \] Common \[ \] Abundant
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Abundance:** \[ \] Rare \[ \] Common \[ \] Abundant
3.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Abundance:** \[ \] Rare \[ \] Common \[ \] Abundant

### Microhabitat Features

**Special habitat features present:**

-   [ ]  Fallen logs - \[ \] Rock outcrops - \[ \] Tree holes - \[ \] Dense thickets
-   [ ]  Open clearings - \[ \] Water edges - \[ \] Steep banks - \[ \] Caves/overhangs
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Microclimate variations noticed:**

-   [ ]  Sunny spots - \[ \] Shady areas - \[ \] Windy areas - \[ \] Sheltered spots
-   [ ]  Wet areas - \[ \] Dry areas - \[ \] Warm spots - \[ \] Cool spots

---

## 📄 Sheet 5: Environmental Variables Measurement

**Print Instructions:** Use for each measurement session

### Measurement Session Info

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Time:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Weather:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Measurer:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Temperature Measurements

**Air temperature:** \_\_\_\_\_ °F/°C **Time:** \_\_\_\_\_ **Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Soil temperature:** \_\_\_\_\_ °F/°C **Depth:** \_\_\_\_\_ **Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Water temperature:** \_\_\_\_\_ °F/°C **Depth:** \_\_\_\_\_ **Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Shade vs. sun difference:** \_\_\_\_\_ °F/°C

### Light Measurements

**Light level method:** \[ \] App \[ \] Light meter \[ \] Visual estimate **Full sun reading:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Units:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Shade reading:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Units:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Deep shade reading:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Units:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Water Quality (if applicable)

**pH:** \_\_\_\_\_ **Method:** \[ \] Test strips \[ \] Digital meter \[ \] Other: \_\_\_\_\_\_\_ **Dissolved oxygen:** \_\_\_\_\_ **ppm** **Method:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Turbidity:** \[ \] Clear \[ \] Slightly cloudy \[ \] Moderately cloudy \[ \] Very cloudy **Odor:** \[ \] None \[ \] Natural/earthy \[ \] Chemical \[ \] Sewage \[ \] Other: \_\_\_\_\_\_\_

### Soil Tests (if applicable)

**pH:** \_\_\_\_\_ **Method:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Moisture:** \_\_\_\_\_ **Method:** \[ \] Meter \[ \] Feel test \[ \] Weight comparison **Compaction:** \[ \] Loose \[ \] Moderate \[ \] Compacted \[ \] Very hard

### Weather Monitoring

**Wind speed:** \_\_\_\_\_ **Method:** \[ \] Anemometer \[ \] Beaufort scale \[ \] Estimate **Wind direction:** \_\_\_\_\_ **Humidity:** \_\_\_\_\_% **Pressure:** \_\_\_\_\_ **Units:** \_\_\_\_\_

### Measurement Quality Notes

**Equipment calibration:** \[ \] Good \[ \] Questionable \[ \] Unknown **Measurement precision:** \[ \] High \[ \] Moderate \[ \] Low **Factors affecting accuracy:**

---

**Repeat measurements needed:** \[ \] Yes \[ \] No **If yes, why:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

## 📄 Sheet 6: Human Impact Assessment

**Print Instructions:** Complete once, update if changes observed

### Infrastructure Assessment

#### Nearby Development

**Distance to nearest:**

-   Road: \_\_\_\_\_ **Type:** \[ \] Major highway \[ \] Local road \[ \] Trail
-   Building: \_\_\_\_\_ **Type:** \[ \] Residential \[ \] Commercial \[ \] Industrial
-   Parking: \_\_\_\_\_ **Size:** \[ \] Small \[ \] Medium \[ \] Large

**Visible infrastructure:**

-   [ ]  Power lines - \[ \] Cell towers - \[ \] Bridges - \[ \] Culverts
-   [ ]  Fences - \[ \] Signs - \[ \] Benches - \[ \] Trash cans
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Land Use History

**Current land use:** \[ \] Natural \[ \] Park \[ \] Agricultural \[ \] Residential \[ \] Commercial **Evidence of past use:**

-   [ ]  Old foundations - \[ \] Fence remnants - \[ \] Non-native plants
-   [ ]  Soil disturbance - \[ \] Drainage modifications - \[ \] Trail systems
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Pollution & Disturbance

#### Litter & Waste

**Litter amount:** \[ \] None \[ \] Light \[ \] Moderate \[ \] Heavy **Litter types:**

-   [ ]  Paper/cardboard - \[ \] Plastic bottles - \[ \] Food waste - \[ \] Cigarette butts
-   [ ]  Metal cans - \[ \] Glass - \[ \] Fabric - \[ \] Electronics
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Organic waste:** \[ \] None \[ \] Pet waste \[ \] Food scraps \[ \] Yard waste **Hazardous materials:** \[ \] None visible \[ \] Chemicals \[ \] Oil \[ \] Paint \[ \] Unknown

#### Air & Water Pollution

**Air quality:** \[ \] Clean \[ \] Slight odor \[ \] Noticeable pollution \[ \] Poor **Pollution sources:**

-   [ ]  Vehicle exhaust - \[ \] Industrial emissions - \[ \] Burning
-   [ ]  Dust - \[ \] Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Water pollution signs:**

-   [ ]  Foam/scum - \[ \] Oil sheen - \[ \] Unusual color - \[ \] Dead fish
-   [ ]  Algae blooms - \[ \] Trash in water - \[ \] Chemical odor
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Habitat Modification

#### Physical Alterations

**Soil compaction:** \[ \] None \[ \] Trails only \[ \] Widespread \[ \] Severe **Erosion evidence:** \[ \] None \[ \] Slight \[ \] Moderate \[ \] Severe **Vegetation damage:**

-   [ ]  Trampling - \[ \] Cutting/pruning - \[ \] Vehicle damage
-   [ ]  Construction impact - \[ \] Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Invasive Species

**Non-native plants observed:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Abundance:** \[ \] Rare \[ \] Common \[ \] Dominant
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Abundance:** \[ \] Rare \[ \] Common \[ \] Dominant
3.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Abundance:** \[ \] Rare \[ \] Common \[ \] Dominant

**Non-native animals observed:**

---

### Positive Human Influences

#### Conservation Efforts

**Management activities observed:**

-   [ ]  Trail maintenance - \[ \] Invasive species removal - \[ \] Planting/restoration
-   [ ]  Erosion control - \[ \] Wildlife habitat improvement - \[ \] Water quality protection
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Educational features:**

-   [ ]  Interpretive signs - \[ \] Trail guides - \[ \] Educational programs
-   [ ]  Volunteer activities - \[ \] Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Community Engagement

**Evidence of community care:**

-   [ ]  Adopt-a-spot programs - \[ \] Clean-up activities - \[ \] Monitoring programs
-   [ ]  Citizen science - \[ \] Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Overall Human Impact Assessment

**Overall impact level:** \[ \] Minimal \[ \] Light \[ \] Moderate \[ \] Heavy \[ \] Severe **Trend:** \[ \] Improving \[ \] Stable \[ \] Declining \[ \] Unknown

**Priority concerns:**

**Recommendations for improvement:**

---

## 📄 Sheet 7: Temporal Change Tracking

**Print Instructions:** One sheet per week of observation

### Time Period Information

**Week #:** \_\_\_\_\_ **Date Range:** \_\_\_\_\_\_\_\_\_\_\_\_\_ to \_\_\_\_\_\_\_\_\_\_\_\_\_ **Number of observation sessions this week:** \_\_\_\_\_ **Total project time elapsed:** \_\_\_\_\_ weeks

### Weekly Change Summary

#### Species Changes

**New species observed this week:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **First seen:** \_\_\_\_\_\_\_\_\_\_\_\_\_
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **First seen:** \_\_\_\_\_\_\_\_\_\_\_\_\_
3.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **First seen:** \_\_\_\_\_\_\_\_\_\_\_\_\_

**Species no longer observed:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Last seen:** \_\_\_\_\_\_\_\_\_\_\_\_\_
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Last seen:** \_\_\_\_\_\_\_\_\_\_\_\_\_

**Abundance changes noted:**

-   **Increased:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   **Decreased:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   **Remained stable:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Physical/Environmental Changes

**Weather pattern changes:**

---

**Vegetation changes:**

-   [ ]  Leaf emergence - \[ \] Flowering - \[ \] Fruiting - \[ \] Leaf color change
-   [ ]  Leaf drop - \[ \] Growth - \[ \] Senescence - \[ \] Other: \_\_\_\_\_\_\_

**Water level changes:** \[ \] Higher \[ \] Lower \[ \] Same \[ \] N/A **Soil moisture changes:** \[ \] Wetter \[ \] Drier \[ \] Same

#### Behavioral Changes

**Animal behavior changes observed:**

---

**Activity level changes:**

-   **More active:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   **Less active:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   **New behaviors:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Seasonal Patterns

#### Expected Changes (based on season)

**What I expected to see this week:**

---

**Did observations match expectations?** \[ \] Yes \[ \] Partially \[ \] No **Explain:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Unexpected Observations

**Surprising changes this week:**

**Possible explanations:**

---

### Data Trends Analysis

#### Quantitative Trends

**Species count trend:** \[ \] Increasing \[ \] Decreasing \[ \] Stable \[ \] Variable **Temperature trend:** \[ \] Warming \[ \] Cooling \[ \] Stable \[ \] Variable **Activity level trend:** \[ \] Increasing \[ \] Decreasing \[ \] Stable \[ \] Variable

#### Pattern Recognition

**Patterns I'm starting to notice:**

**Correlations between variables:**

-   **When \_\_\_\_\_\_\_ increases, \_\_\_\_\_\_\_ also increases**
-   **When \_\_\_\_\_\_\_ decreases, \_\_\_\_\_\_\_ decreases**
-   **\_\_\_\_\_\_\_ seems unrelated to \_\_\_\_\_\_\_**

### Predictions & Hypotheses

#### Predictions for Next Week

**Based on trends, I predict:**

**What I want to pay special attention to:**

---

#### Hypothesis Development

**New hypotheses forming:**

**How I could test these:**

---

### AI Collaboration Notes

**AI analysis prompt used this week:**

---

**AI insights about temporal patterns:**

---

**AI predictions I want to test:**

---

## 📄 Sheet 8: Photo & Sample Documentation Log

**Print Instructions:** Multiple copies recommended

### Documentation Session Info

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Time:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Photographer:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Camera/Device:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Weather/Lighting:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Photo Log

| Photo # | Subject | Location | Time | Purpose | Notes |
| --- | --- | --- | --- | --- | --- |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |

### Detailed Photo Descriptions

#### Photo Set #1: \[Description, e.g., "Site Overview"\]

**Photos #:** \_\_\_\_\_ to \_\_\_\_\_ **Purpose:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Key features to highlight:**

**GPS location (if available):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Direction facing:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Scale reference:** \_\_\_\_\_\_\_\_\_\_\_\_\_

#### Photo Set #2: \[Description\]

**Photos #:** \_\_\_\_\_ to \_\_\_\_\_ **Purpose:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Key features to highlight:**

**GPS location (if available):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Direction facing:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Scale reference:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Species Photo Documentation

#### Species Requiring ID Verification

**Photo #:** \_\_\_\_\_ **Species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Description:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Distinguishing features captured:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Additional photos needed:** \[ \] Yes \[ \] No **What:** \_\_\_\_\_\_\_\_\_\_\_\_\_

**Photo #:** \_\_\_\_\_ **Species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Description:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Distinguishing features captured:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Additional photos needed:** \[ \] Yes \[ \] No **What:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### Sample Collection Log (if applicable)

**Sample #1:** **Type:** \[ \] Plant \[ \] Soil \[ \] Water \[ \] Insect \[ \] Other: \_\_\_\_\_\_\_ **Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Collection method:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Storage:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Purpose:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Photo documentation:** Photo #\_\_\_\_\_

**Sample #2:** **Type:** \[ \] Plant \[ \] Soil \[ \] Water \[ \] Insect \[ \] Other: \_\_\_\_\_\_\_ **Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Collection method:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Storage:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Purpose:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Photo documentation:** Photo #\_\_\_\_\_

### Quality Control

#### Photo Quality Assessment

**Focus quality:** \[ \] Excellent \[ \] Good \[ \] Acceptable \[ \] Poor **Lighting:** \[ \] Excellent \[ \] Good \[ \] Acceptable \[ \] Poor **Composition:** \[ \] Excellent \[ \] Good \[ \] Acceptable \[ \] Poor **Photos needing retakes:** \_\_\_\_\_

#### Backup & Organization

**Photos backed up:** \[ \] Yes \[ \] No **Method:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **File organization system:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Cloud storage:** \[ \] Yes \[ \] No **Platform:** \_\_\_\_\_\_\_\_\_\_\_\_\_

### AI Photo Analysis Notes

#### AI-Assisted Species ID

**Photo #:** \_\_\_\_\_ **AI platform used:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **AI identification:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence level:** \_\_\_\_\_ **Additional verification:** \[ \] Needed \[ \] Complete

**Photo #:** \_\_\_\_\_ **AI platform used:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **AI identification:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence level:** \_\_\_\_\_ **Additional verification:** \[ \] Needed \[ \] Complete

#### AI Analysis of Photo Patterns

**AI insights about photo collection:**

---

**Suggested improvements for photo documentation:**

---

## 📄 Sheet 9: AI Collaboration Tracking Sheet

**Print Instructions:** Multiple copies recommended - use one per week

### Weekly AI Interaction Summary

**Week of:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Observer:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Total AI interactions this week:** \_\_\_\_\_

### AI Platform Usage

#### Platforms Used This Week

-   [ ]  ChatGPT **Interactions:** \_\_\_\_\_ **Primary uses:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  Claude **Interactions:** \_\_\_\_\_ **Primary uses:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  Perplexity **Interactions:** \_\_\_\_\_ **Primary uses:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  Google Bard **Interactions:** \_\_\_\_\_ **Primary uses:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  iNaturalist AI **Interactions:** \_\_\_\_\_ **Primary uses:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  Other: \_\_\_\_\_\_\_ **Interactions:** \_\_\_\_\_ **Primary uses:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### AI Assistance Categories

#### Research & Background Information

**Sessions:** \_\_\_\_\_ **Quality:** \[ \] Excellent \[ \] Good \[ \] Fair \[ \] Poor **Most valuable insights:**

---

**Information requiring verification:**

---

#### Species Identification

**Sessions:** \_\_\_\_\_ **Accuracy:** \_\_\_\_\_ % (estimated) **Successful identifications:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence:** \_\_\_\_\_
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence:** \_\_\_\_\_
3.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence:** \_\_\_\_\_

**Unsuccessful/uncertain identifications:**

1.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Issue:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Issue:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Data Analysis Support

**Sessions:** \_\_\_\_\_ **Helpfulness:** \[ \] Very \[ \] Moderately \[ \] Slightly \[ \] Not **Patterns AI helped identify:**

**AI analysis I disagreed with:**

---

**Why:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Question & Hypothesis Development

**Sessions:** \_\_\_\_\_ **Creativity level:** \[ \] High \[ \] Moderate \[ \] Low **Best AI-suggested questions:**

**Questions I developed independently:**

### AI Verification Tracking

#### Information Verified This Week

**Claim #1:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **AI Source:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Verification method:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Result:** \[ \] Confirmed \[ \] Partially confirmed \[ \] Contradicted \[ \] Uncertain

**Claim #2:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **AI Source:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Verification method:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Result:** \[ \] Confirmed \[ \] Partially confirmed \[ \] Contradicted \[ \] Uncertain

**Claim #3:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **AI Source:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Verification method:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Result:** \[ \] Confirmed \[ \] Partially confirmed \[ \] Contradicted \[ \] Uncertain

#### AI Errors Identified

**Error #1:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **How I discovered it:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Correct information:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Error #2:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **How I discovered it:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Correct information:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Prompt Development Skills

#### Most Effective Prompts This Week

**Best prompt for species ID:**

```
________________________________
________________________________
```

**Why it worked:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Best prompt for analysis:**

```
________________________________
________________________________
```

**Why it worked:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Prompt Improvements Made

**Original prompt:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Improved prompt:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Better results achieved:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### AI Collaboration Reflection

#### Learning Assessment

**New AI skills developed this week:**

-   [ ]  Better prompt writing
-   [ ]  More effective verification
-   [ ]  Improved critical evaluation
-   [ ]  Better integration with fieldwork
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**AI collaboration challenges:**

#### Balance of AI vs. Personal Work

**Tasks where AI was most helpful:**

**Tasks where my human skills were essential:**

**Overall assessment of AI contribution this week:** \[ \] Too much reliance \[ \] Good balance \[ \] Could use more \[ \] Unsure

### Action Items for Next Week

**AI collaboration goals:**

**Verification priorities:**

**New AI techniques to try:**

---

## 📄 Sheet 10: Weekly Reflection & Analysis

**Print Instructions:** One sheet per week - use for synthesis and planning

### Week \_\_\_\_\_ Summary

**Date Range:** \_\_\_\_\_\_\_\_\_\_\_\_\_ to \_\_\_\_\_\_\_\_\_\_\_\_\_ **Total field time this week:** \_\_\_\_\_ hours **Weather summary:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Data Collection Assessment

#### Quantitative Summary

**Species observations:** \_\_\_\_\_ total **New species this week:** \_\_\_\_\_ **Environmental measurements:** \_\_\_\_\_ taken **Photos captured:** \_\_\_\_\_ total **Samples collected:** \_\_\_\_\_ total

#### Data Quality Evaluation

**Completeness:** \[ \] Excellent \[ \] Good \[ \] Adequate \[ \] Poor **Accuracy:** \[ \] High confidence \[ \] Moderate \[ \] Low \[ \] Uncertain **Consistency:** \[ \] Very consistent \[ \] Mostly \[ \] Some gaps \[ \] Inconsistent

**Data gaps identified:**

**Plan to address gaps:**

---

### Pattern Recognition & Analysis

#### Patterns Observed This Week

**Biological patterns:**

**Environmental patterns:**

**Temporal patterns:**

#### Cross-Week Comparisons

**Compared to last week:**

-   **Species diversity:** \[ \] Higher \[ \] Lower \[ \] Same
-   **Activity levels:** \[ \] Higher \[ \] Lower \[ \] Same
-   **Environmental conditions:** \[ \] Different \[ \] Similar

**Trend analysis:** **Increasing:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Decreasing:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Remaining stable:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Research Question Progress

#### Hypothesis Testing

**Hypothesis #1:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Evidence this week:** \[ \] Supports \[ \] Contradicts \[ \] Neutral \[ \] Unclear **Explanation:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Hypothesis #2:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Evidence this week:** \[ \] Supports \[ \] Contradicts \[ \] Neutral \[ \] Unclear **Explanation:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Hypothesis #3:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Evidence this week:** \[ \] Supports \[ \] Contradicts \[ \] Neutral \[ \] Unclear **Explanation:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Research Question Evolution

**Original question:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**How my understanding has changed:**

---

**New questions arising:**

### AI Collaboration Integration

#### AI Insights This Week

**Most valuable AI contribution:**

---

**AI suggestions I implemented:**

**AI suggestions I rejected and why:**

1.  **Reason:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Human-AI Synthesis

**Findings I discovered independently:**

**Findings enhanced by AI analysis:**

**Areas where AI couldn't help:**

### Learning & Skill Development

#### Scientific Skills Practiced

-   [ ]  Systematic observation
-   [ ]  Data recording
-   [ ]  Pattern recognition
-   [ ]  Hypothesis testing
-   [ ]  Critical thinking
-   [ ]  Scientific writing
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### AI Collaboration Skills Developed

-   [ ]  Effective prompting
-   [ ]  Information verification
-   [ ]  Critical evaluation
-   [ ]  Integration techniques
-   [ ]  Error recognition
-   [ ]  Balanced usage
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Most Significant Learning This Week

**About ecosystems:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **About scientific methodology:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **About AI collaboration:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **About myself as a researcher:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Challenges & Problem-Solving

#### Challenges Encountered

**Field work challenges:**

**AI collaboration challenges:**

**Data analysis challenges:**

#### Solutions Implemented

**Problem:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Solution tried:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Effectiveness:** \[ \] Very effective \[ \] Somewhat \[ \] Not effective

**Problem:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Solution tried:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Effectiveness:** \[ \] Very effective \[ \] Somewhat \[ \] Not effective

### Planning for Next Week

#### Research Priorities

**Top 3 priorities for next week:**

**Data collection focus:**

---

**AI collaboration goals:**

#### Methodology Adjustments

**Changes to make based on this week's experience:**

---

**New techniques to try:**

---

**Equipment needed:**

---

#### Questions to Investigate

**Follow-up questions from this week:**

**AI research prompts to prepare:**

### Long-term Project Reflection

#### Progress Toward Research Goals

**Original research question:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Progress assessment:** \[ \] On track \[ \] Ahead of schedule \[ \] Behind schedule \[ \] Need to refocus

**Confidence in eventual answer:** \[ \] High \[ \] Moderate \[ \] Low \[ \] Uncertain

#### Project Timeline Check

**Weeks completed:** \_\_\_\_\_ **Weeks remaining:** \_\_\_\_\_ **Data collection:** \[ \] Complete \[ \] On schedule \[ \] Behind \[ \] Need extension **Analysis phase:** \[ \] Not started \[ \] Beginning \[ \] In progress \[ \] Complete **Presentation prep:** \[ \] Not started \[ \] Beginning \[ \] In progress \[ \] Complete

#### Skills Development Assessment

**Strongest scientific skills developed:**

**AI collaboration skills mastered:**

**Areas still needing improvement:**

#### Overall Learning Assessment

**Most surprising discovery about ecosystems:**

---

**Most valuable AI collaboration insight:**

---

**How this project changed my understanding of science:**

---

**Confidence in my ability to conduct independent research:** \[ \] Much higher \[ \] Somewhat higher \[ \] Same \[ \] Lower

---

## 📋 Data Sheet Usage Guidelines

### Getting Started

1.  **Print multiple copies** of sheets you'll use repeatedly (Daily Observation, Species Survey, AI Collaboration)
2.  **Complete Sheet 1 first** to establish your project framework
3.  **Keep sheets in a sturdy folder** or binder for field use
4.  **Bring backup writing materials** (pen/pencil) to every field session

### Field Usage Tips

-   **Complete forms immediately** during or right after observations
-   **Use pencil for outdoor work** (more weather-resistant than pen)
-   **Take photos of completed sheets** as backup documentation
-   **Note any unusual circumstances** that might affect data quality

### AI Integration Best Practices

-   **Document every AI interaction** using Sheet 9
-   **Verify important AI claims** before incorporating into analysis
-   **Balance AI assistance** with independent observation and thinking
-   **Use AI collaboration log** to track learning progression

### Quality Assurance

-   **Review completed sheets daily** for completeness and clarity
-   **Cross-check information** between different sheet types
-   **Get peer or teacher feedback** on data collection techniques
-   **Maintain consistent methodology** throughout the project

### Data Management

-   **Organize sheets chronologically** by date and sheet type
-   **Create digital backups** by photographing or scanning completed sheets
-   **Summarize weekly progress** using reflection sheets
-   **Prepare final data compilation** for analysis and presentation

### Troubleshooting Common Issues

#### Incomplete Data

**Problem:** Missing information on data sheets **Solution:** Establish daily review routine, use checklists, set phone reminders

#### Inconsistent Methodology

**Problem:** Changing observation techniques mid-project **Solution:** Refer back to Sheet 1 setup, note any necessary changes with justification

#### AI Collaboration Confusion

**Problem:** Unclear about when/how to use AI assistance **Solution:** Review AI ethics guidelines, consult with teacher, use structured prompts

#### Weather/Access Problems

**Problem:** Field conditions preventing data collection **Solution:** Document conditions, use backup observation methods, extend timeline if needed

### Customization Notes

-   **Modify sheets** for specific ecosystem types or research focuses
-   **Add sections** for unique project requirements
-   **Combine sheets** for shorter projects or limited time
-   **Scale complexity** based on grade level and project scope

### Assessment Integration

-   **Use completed sheets** as evidence for project grading
-   **Include reflection sheets** in portfolio assessment
-   **Reference AI collaboration logs** for digital literacy evaluation
-   **Demonstrate data quality** through systematic documentation

---

## 📖 Additional Resources

### Recommended Field Guides

-   **Regional plant identification guides**
-   **Local bird identification resources**
-   **Insect and invertebrate field guides**
-   **Geological and soil identification materials**

### Digital Tools

-   **iNaturalist app** for species identification and verification
-   **Weather apps** for accurate environmental data
-   **GPS/mapping apps** for location documentation
-   **Cloud storage** for photo and data backup

### Safety Resources

-   **Local emergency contact information**
-   **First aid kit recommendations**
-   **Weather monitoring resources**
-   **Site-specific safety guidelines**

### Academic Support

-   **Citation guidelines** for AI assistance documentation
-   **Scientific writing resources**
-   **Data analysis tutorials**
-   **Presentation preparation guides**

---

**Remember: These data collection sheets are tools to support your learning and discovery. The most important element is your careful observation, critical thinking, and genuine curiosity about the natural world around you!** 🌱📊

---

**Version History:**

-   v1.0 (August 2025): Initial release with 10 comprehensive data collection sheets
-   Compatible with: AI Collaboration Guide, Assessment Rubric, Research Templates
-   Repository: GitHub Education Resources

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `classroom-tools/project-templates/systems-thinking-projects/local-ecosystem-study/resources/data-collection-sheets.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
