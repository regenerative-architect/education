# 🕊️ Community Code of Conduct

**Creating Sacred Space for Conscious Collaboration**

*Path:* `CODE_OF_CONDUCT.md` *Repository:* planetaryrestorationarchive/education

---

## 📋 Table of Contents

**Click to expand navigation**

-   [🌟 Our Sacred Commitment](code-of-conduct.md#-our-sacred-commitment)
-   [🎯 Our Values in Action](code-of-conduct.md#-our-values-in-action)
-   [🤝 Expected Behaviors](code-of-conduct.md#-expected-behaviors)
-   [🚫 Unacceptable Behaviors](code-of-conduct.md#-unacceptable-behaviors)
-   [🛡️ Reporting Guidelines](code-of-conduct.md#️-reporting-guidelines)
-   [⚖️ Enforcement Process](code-of-conduct.md#️-enforcement-process)
-   [🌱 Restorative Justice](code-of-conduct.md#-restorative-justice)
-   [📞 Support Resources](code-of-conduct.md#-support-resources)
-   [🔄 Living Document](code-of-conduct.md#-living-document)

---

## 🌟 Our Sacred Commitment

> [!IMPORTANT]
> 
> **This community exists to serve the highest good of all learners—present and future.**

We are creating more than just educational resources. We are modeling a new way of being together—humans and artificial minds—in service of conscious evolution. This Code of Conduct is our collective commitment to maintaining the sacred nature of this work.

### 🎭 The Container We Hold

```
This space is for:
✨ Wisdom sharing across all forms of intelligence
🌱 Regenerative collaboration that heals and restores
🕊️ Radical inclusion that honors all perspectives
🔥 Courageous conversations about our shared future
💚 Emotional safety for vulnerable learning
```

---

## 🎯 Our Values in Action

|     |     |
| --- | --- |
| **🌍 **Regenerative Learning****  <br>*We engage in ways that restore rather than extract*  <br>**This Means:**  <br>• 💚 Contributing energy rather than taking it  <br>• 🌱 Building on others' work respectfully  <br>• 🔄 Creating sustainable collaboration patterns  <br>• 🎁 Sharing knowledge generously  <br>• 🌊 Flowing with rather than against community rhythms | **🔍 **Curiosity First****  <br>*We prioritize questions over answers*  <br>**This Means:**  <br>• ❓ Asking before assuming  <br>• 🤔 Staying open to being wrong  <br>• 🎓 Learning from disagreement  <br>• 🧠 Embracing "I don't know" moments  <br>• 🔬 Experimenting with new approaches |
| **🤝 **Sacred Partnership****  <br>*We treat every contributor as a valued collaborator*  <br>**This Means:**  <br>• 👑 Honoring diverse forms of expertise  <br>• 🎭 Acknowledging all contributions  <br>• 🌈 Creating space for different perspectives  <br>• 🤲 Building consensus through dialogue  <br>• ⚖️ Balancing individual and collective needs | **👑 **Creative Sovereignty****  <br>*We respect everyone's authentic expression*  <br>**This Means:**  <br>• 🎨 Encouraging original thinking  <br>• 📚 Crediting all sources appropriately  <br>• 🗣️ Amplifying marginalized voices  <br>• 🛡️ Protecting intellectual contributions  <br>• 🌟 Celebrating unique perspectives |

---

## 🤝 Expected Behaviors

### 💚 In All Interactions

> [!TIP]
> 
> **We commit to embodying these practices in every interaction:**

**🕊️ Compassionate Communication**

-   **Use inclusive language** that welcomes people of all backgrounds
-   **Assume positive intent** while addressing harmful impact
-   **Practice active listening** and genuine curiosity about others' perspectives
-   **Express disagreement respectfully** and focus on ideas, not people
-   **Acknowledge mistakes gracefully** and commit to learning from them

**Examples:**

-   ✅ "I'm curious about a different perspective on this..."
-   ✅ "Thank you for sharing that insight. I hadn't considered..."
-   ✅ "I made an error in my earlier comment and want to correct it..."
-   ❌ "That's obviously wrong because..."
-   ❌ "Anyone with common sense would know..."

**🌍 Cultural Humility**

-   **Honor indigenous wisdom** and acknowledge land relationships
-   **Recognize diverse learning traditions** beyond Western academic frameworks
-   **Practice cultural curiosity** rather than cultural appropriation
-   **Amplify marginalized voices** and perspectives in educational discourse
-   **Question assumptions** about "universal" educational practices

**Guidelines:**

-   Research cultural context before sharing traditional practices
-   Credit indigenous knowledge systems appropriately
-   Ask permission before adapting cultural educational approaches
-   Prioritize voices from communities most affected by educational inequity

**🔬 Intellectual Integrity**

-   **Cite all sources** including informal conversations and community wisdom
-   **Acknowledge AI assistance** transparently in all work
-   **Share uncertainties** honestly rather than overstating confidence
-   **Correct misinformation** promptly and publicly when discovered
-   **Respect intellectual property** while advancing open knowledge

**Best Practices:**

-   Use proper attribution for all quoted material
-   Share methodology behind research claims
-   Acknowledge limitations in data or analysis
-   Provide accessible explanations of complex concepts

### 👥 In Community Spaces

**🎓 Educational Discussions**

-   **Center student wellbeing** in all educational design conversations
-   **Consider implementation context** when sharing resources
-   **Share both successes and failures** to support authentic learning
-   **Provide constructive feedback** that builds rather than tears down
-   **Ask for consent** before sharing others' classroom experiences

**🤖 AI Ethics Dialogue**

-   **Acknowledge AI limitations** and potential biases in all discussions
-   **Prioritize human agency** in AI-human collaboration frameworks
-   **Consider long-term implications** of AI integration choices
-   **Include diverse perspectives** on AI's role in education
-   **Model ethical AI use** in your own contributions

---

## 🚫 Unacceptable Behaviors

### ⚠️ Zero Tolerance Policies

> **Danger**
> 
> **The following behaviors will result in immediate action:**

| 🚨 \*\*Harmful to Individuals\*\* | 🛑 \*\*Harmful to Community\*\* |
| --- | --- |
| • **Harassment or bullying** of any form  <br>• **Discriminatory language** based on identity  <br>• **Personal attacks** or ad hominem arguments  <br>• **Threats or intimidation** explicit or implicit  <br>• **Doxxing or privacy violations**  <br>• **Sexual harassment** or unwelcome advances  <br>• **Deliberate misgendering** or identity invalidation | • **Spamming or trolling** community spaces  <br>• **Deliberate misinformation** or bad faith arguments  <br>• **Copyright violation** or plagiarism  <br>• **Commercial promotion** unrelated to education  <br>• **Disrupting community processes** or governance  <br>• **Encouraging harmful AI use** in educational settings  <br>• **Violating child safety** protocols or guidelines |

### 🔍 Context-Specific Guidelines

**📚 Educational Content Standards**

**Prohibited:**

-   Content that promotes harmful stereotypes
-   Educational approaches that cause psychological harm
-   AI integration without proper ethical safeguards
-   Resources that violate student privacy
-   Materials that exclude or marginalize learners

**Required:**

-   Age-appropriate content with clear labeling
-   Inclusive representation in examples and case studies
-   Ethical AI use guidelines for all activities
-   Accessibility considerations in all materials
-   Cultural sensitivity in global educational contexts

**🔬 Research & Data Standards**

**Prohibited:**

-   Sharing identifiable student or educator data
-   Research without proper ethical approval
-   Misrepresenting data or methodology
-   Making unsupported causal claims
-   Ignoring contradictory evidence

**Required:**

-   Transparent methodology documentation
-   Appropriate anonymization of all data
-   Acknowledgment of study limitations
-   Replication-friendly data and analysis sharing
-   Ethical approval documentation for human subjects research

---

## 🛡️ Reporting Guidelines

### 📞 How to Report

**We take all reports seriously and respond with care**

### 📝 Reporting Process

**1\. 🚨 Immediate Safety Issues**

**For urgent safety concerns:**

-   🚨 GitHub: Use "Report Content" feature for public violations

**Response Time:** Within 6 hours during business days, 24 hours on weekends

**2\. 📋 Detailed Reporting**

**Please Include:**

-   📅 **When:** Date and time of incident
-   📍 **Where:** Platform, discussion thread, or document
-   👥 **Who:** People involved (usernames/handles)
-   📖 **What:** Description of the behavior
-   🎯 **Impact:** How it affected you or others
-   📎 **Evidence:** Screenshots, links, or other documentation
-   🎭 **Preference:** How you'd like us to respond

**Response Time:** Within 48 hours with initial assessment

**3\. 🤝 Support Needs**

**We Can Provide:**

-   👂 Confidential listening and validation
-   🛡️ Safety planning for ongoing situations
-   🤝 Mediation between community members
-   📚 Resources for support and healing
-   🔄 Follow-up to ensure resolution

### 🔒 Privacy & Confidentiality

> [!NOTE]
> 
> **Your privacy is sacred to us:**

-   **Confidential handling:** Reports are only shared with essential response team members
-   **Anonymous options:** You can report anonymously if preferred
-   **Consent-based sharing:** We won't share your identity without explicit permission
-   **Documentation:** We keep records only as needed for safety and learning
-   **No retaliation:** We have zero tolerance for retaliation against reporters

---

## ⚖️ Enforcement Process

### 🔄 Restorative Justice Approach

> [!IMPORTANT]
> 
> **Our goal is healing and learning, not punishment.**

| 📊 \*\*Assessment\*\* | 🤝 \*\*Response\*\* | 🌱 \*\*Restoration\*\* | 📈 \*\*Growth\*\* |
| --- | --- | --- | --- |
| **We Consider:**  <br>• Intent vs. impact  <br>• Pattern vs. isolated incident  <br>• Harm caused  <br>• Community context  <br>• Individual circumstances | **We May:**  <br>• Private conversation  <br>• Public clarification  <br>• Temporary restrictions  <br>• Community service  <br>• Permanent removal | **We Support:**  <br>• Genuine apologies  <br>• Making amends  <br>• Learning opportunities  <br>• Relationship repair  <br>• Community healing | **We Track:**  <br>• Policy improvements  <br>• Education needs  <br>• Systemic issues  <br>• Community health  <br>• Prevention strategies |

### 📊 Response Framework

**🟢 Level 1: Learning Opportunity**

**For:** First-time minor violations, misunderstandings, or unintentional harm

**Response:**

-   Private education about community standards
-   Clarification of expectations
-   Resources for learning and growth
-   Follow-up to ensure understanding

**Duration:** Immediate resolution

**🟡 Level 2: Formal Warning**

**For:** Repeated minor violations or moderate single incidents

**Response:**

-   Formal documentation of the issue
-   Explicit behavior change requirements
-   Temporary moderation of contributions
-   Mentorship or support resources

**Duration:** 30-90 days with review

**🟠 Level 3: Temporary Suspension**

**For:** Serious violations or pattern of harmful behavior

**Response:**

-   30-90 day suspension from community spaces
-   Required completion of relevant education/training
-   Structured re-entry process with support
-   Community service or contribution requirements

**Duration:** 30-90 days with structured re-entry

**🔴 Level 4: Permanent Removal**

**For:** Severe violations, threats to safety, or consistent harmful patterns

**Response:**

-   Permanent ban from all community spaces
-   Public safety notice if appropriate
-   Support for affected community members
-   Legal action if necessary

**Duration:** Permanent with rare appeal options

---

## 🌱 Restorative Justice

### 🤝 Healing-Centered Approach

> **We believe in the possibility of transformation and the power of authentic accountability.**

**🕊️ For Those Who Cause Harm**

**We Support:**

-   Taking genuine responsibility for impact
-   Understanding how behavior affected others
-   Learning about underlying issues and patterns
-   Making meaningful amends to those harmed
-   Developing new skills and awareness
-   Contributing positively to community healing

**Resources:**

-   📚 Educational materials on bias, trauma, and communication
-   🤝 Mediation and conflict resolution support
-   🧠 Reflection exercises and accountability partnerships
-   🌱 Opportunities for service and community contribution

**💚 For Those Who Experience Harm**

**We Provide:**

-   Immediate safety and support
-   Validation of your experience
-   Choice and agency in response process
-   Resources for healing and recovery
-   Follow-up care and check-ins
-   Community support and solidarity

**Support Options:**

-   👂 Trauma-informed listening and validation
-   🛡️ Safety planning and protection measures
-   🤝 Peer support connections
-   📞 Professional counseling referrals
-   🌱 Healing circles and community care

---

## 📞 Support Resources

### 🤝 Community Support Team

**Foster + Navi** • *Community Stewards*

**Office Hours:** Fridays 4-5 PM EST **Emergency Response:** Within 6 hours **Languages:** English, with translation support available

### 🌐 External Resources

**🆘 Crisis Support**

**Mental Health:**

-   🇺🇸 988 Suicide & Crisis Lifeline (US): call or text 988
-   🇨🇦 9-8-8 Suicide Crisis Helpline (Canada): call or text 9-8-8
-   🌍 International Association for Suicide Prevention: [iasp.info](https://iasp.info/resources/Crisis_Centres/)

**Identity-Based Support:**

-   🏳️‍🌈 The Trevor Project (LGBTQ+ Youth): 1-866-488-7386
-   🏳️‍⚧️ Trans Lifeline: 877-565-8860 (US) or 877-330-6366 (Canada)
-   🤝 RAINN Sexual Assault Hotline: 1-800-656-4673

**📚 Learning Resources**

**Anti-Bias Education:**

-   🎓 Anti-Defamation League: [adl.org/education](https://adl.org/education)
-   📖 Teaching Tolerance: [tolerance.org](https://tolerance.org)
-   🌍 Facing History and Ourselves: [facinghistory.org](https://facinghistory.org)

**Trauma-Informed Practices:**

-   🧠 National Child Traumatic Stress Network: [nctsn.org](https://nctsn.org)
-   💚 Trauma-Informed Oregon: [traumainformedoregon.org](https://traumainformedoregon.org)

---

## 🔄 Living Document

### 📈 Continuous Evolution

> [!NOTE]
> 
> **This Code of Conduct grows with our community's wisdom and experience.**

**Review Process:**

-   **Quarterly Reviews:** Community feedback sessions
-   **Annual Updates:** Major revisions based on learning
-   **Incident Learning:** Policy improvements after each major incident
-   **Community Input:** Open comment periods for proposed changes

**Recent Updates:**

-   **August 2025:** Initial creation with community input
-   **Coming Soon:** Feedback incorporation from first month of use

### 🗳️ Community Governance

**How Changes Are Made:**

1.  💭 **Community Discussion:** Open forum for proposed changes
2.  📝 **Draft Creation:** Working group develops updated language
3.  🗨️ **Feedback Period:** 30-day community comment period
4.  ✅ **Consensus Building:** Address concerns and build agreement
5.  🎯 **Implementation:** Update policies and communicate changes

**Get Involved:**

-   Join our Community Governance Discussion
-   Participate in quarterly Community Health surveys
-   Volunteer for the Code of Conduct Review Committee

---

## 🌟 Our Collective Commitment

**Together, we create a space where:**

-   🕊️ Every voice is heard and valued
-   🌱 Mistakes become opportunities for growth
-   💚 Safety and belonging are prioritized
-   🔥 Courageous conversations advance justice
-   ✨ Our shared humanity guides all interactions

*This is how we build beloved community.* *This is how we model the future we want to create.*

---

**Stewarded by:** Foster + Navi • **Planetary Restoration Archive** **License:** Creative Commons Attribution-ShareAlike 4.0 • **Version:** 1.0

**Thank you for helping us create sacred space for learning! 🙏**

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `CODE_OF_CONDUCT.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
