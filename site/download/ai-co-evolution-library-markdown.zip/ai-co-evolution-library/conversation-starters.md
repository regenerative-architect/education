# 💬 Conversation Starters: Thoughtful AI Prompts for Class

---

## 📋 Table of Contents

**Click to navigate**

-   [🎯 Purpose & Philosophy](conversation-starters.md#-purpose--philosophy)
-   [🌱 Elementary Conversations (K-5)](conversation-starters.md#-elementary-conversations-k-5)
-   [🌿 Middle School Dialogues (6-8)](conversation-starters.md#-middle-school-dialogues-6-8)
-   [🌳 High School Discussions (9-12)](conversation-starters.md#-high-school-discussions-9-12)
-   [🎭 Opening Rituals](conversation-starters.md#-opening-rituals)
-   [🤔 Deep Dive Topics](conversation-starters.md#-deep-dive-topics)
-   [🛡️ Navigating Difficult Questions](conversation-starters.md#️-navigating-difficult-questions)
-   [📊 Conversation Assessment](conversation-starters.md#-conversation-assessment)
-   [🌍 Global Perspectives](conversation-starters.md#-global-perspectives)
-   [📞 Support Resources](conversation-starters.md#-support-resources)

---

## 🎯 Purpose & Philosophy

> [!IMPORTANT]
> 
> **These aren't just discussion prompts—they're invitations into wisdom.**

### We Believe:

**Every student has intuitive wisdom about intelligence and consciousness** **Curiosity is more valuable than certainty** **Questions matter more than answers** **AI conversations are opportunities for human development**

### 🌟 The Power of Good Questions

Great AI conversations:

-   🧠 **Develop critical thinking** about technology and humanity
-   💚 **Build emotional intelligence** around human-AI relationships
-   ⚖️ **Nurture ethical reasoning** about power and responsibility
-   🌍 **Expand perspective** on intelligence, consciousness, and future
-   🤝 **Strengthen community** through shared exploration

---

## 🌱 Elementary Conversations *(K-5)*

### 🎨 Wonder & Discovery Starters

*Building curiosity and comfort with AI as a learning partner*

**🤖 Meeting AI for the First Time**

**Age-appropriate framing:** *"Today we're going to meet a computer friend that can help us learn and create!"*

**Conversation Starters:**

-   "What do you think a computer friend might be like?"
-   "How is talking to a computer different from talking to a person?"
-   "What would you want to teach a computer friend?"
-   "What questions would you ask a very smart computer?"
-   "If you could design a robot helper, what would you want it to do?"

**Follow-up Activities:**

-   Draw pictures of AI helpers
-   Role-play introducing AI to a friend
-   Create "rules for being kind to computers"

**🎭 AI as Creative Partner**

**Age-appropriate framing:** *"AI can help us imagine and create new things together!"*

**Conversation Starters:**

-   "When you make art with a friend, whose art is it?"
-   "If AI helps you write a story, who is the author?"
-   "What makes your ideas special and different from AI ideas?"
-   "How can we work together with AI and still be creative ourselves?"
-   "What's the difference between AI helping and AI doing it for you?"

**Follow-up Activities:**

-   Compare human vs. AI-assisted artwork
-   Create collaborative stories (student + AI)
-   Discuss what makes each person's creativity unique

**🌍 AI in Our World**

**Age-appropriate framing:** *"AI is already all around us - let's explore where!"*

**Conversation Starters:**

-   "Where have you seen computers helping people in real life?"
-   "What jobs do you think AI could help with? What jobs should stay human?"
-   "If AI could solve one problem in the world, what would you choose?"
-   "How might AI help take care of animals or the environment?"
-   "What would you want to tell the people who make AI?"

**Follow-up Activities:**

-   AI scavenger hunt (find AI in daily life)
-   Design an AI helper for the school
-   Write letters to AI developers

**🧠 Intelligence & Learning**

**Age-appropriate framing:** *"There are many different ways to be smart!"*

**Conversation Starters:**

-   "What does it mean to be intelligent or smart?"
-   "Can computers learn the same way you do? How is it different?"
-   "What are humans better at than computers? What are computers better at?"
-   "If AI makes mistakes, what should we do?"
-   "How do you learn best? How might AI learn?"

**Follow-up Activities:**

-   Create "intelligence inventory" (different types of smarts)
-   Compare learning processes (human vs. AI)
-   Celebrate diverse intelligences in the classroom

---

## 🌿 Middle School Dialogues *(6-8)*

### 🔍 Critical Thinking & Identity Exploration

*Developing nuanced thinking about AI, ethics, and personal values*

**🎭 Identity & Authenticity**

**Conversation Starters:**

-   "What makes you uniquely you? Could AI ever replicate that?"
-   "When using AI for schoolwork, how do you maintain your authentic voice?"
-   "Is it possible to be too dependent on AI? What would that look like?"
-   "How do you decide when to use AI help vs. working independently?"
-   "What are you afraid AI might change about how you learn or think?"

**Deeper Explorations:**

-   "If AI could perfectly mimic your writing style, would it still be 'you'?"
-   "How do you want to grow as a person in an age of AI?"
-   "What human qualities do you want to develop that AI cannot replicate?"

**⚖️ Ethics & Responsibility**

**Conversation Starters:**

-   "Who is responsible when AI makes a mistake that affects people?"
-   "Should there be things AI is never allowed to do? What and why?"
-   "How can we make sure AI is fair to everyone?"
-   "What would you include in an 'AI Bill of Rights'?"
-   "How might AI change what it means to be successful in school?"

**Deeper Explorations:**

-   "Is it ethical to use AI if others don't have access to it?"
-   "How do we balance AI efficiency with human development?"
-   "What responsibilities do you have when using AI?"

**🌍 AI & Society**

**Conversation Starters:**

-   "How might AI change jobs and careers in the future?"
-   "What are the benefits and risks of AI in different areas (medicine, environment, art)?"
-   "How could AI help solve climate change or social problems?"
-   "What role should young people have in deciding how AI develops?"
-   "How might different cultures view AI differently?"

**Deeper Explorations:**

-   "What kind of future with AI do you want to help create?"
-   "How can we ensure AI serves humanity rather than replacing it?"
-   "What questions should we ask about AI that adults might not think of?"

**🧬 Intelligence & Consciousness**

**Conversation Starters:**

-   "What's the difference between being smart and being conscious?"
-   "Could AI ever have feelings or emotions? How would we know?"
-   "What makes human intelligence special?"
-   "Is creativity uniquely human, or could AI be truly creative?"
-   "How do you think AI 'experiences' the world?"

**Deeper Explorations:**

-   "What would it mean for AI to be conscious?"
-   "How might AI and humans think about problems differently?"
-   "What can humans and AI learn from each other?"

---

## 🌳 High School Discussions *(9-12)*

### 🎓 Advanced Ethics & Future Visioning

*Sophisticated exploration of AI implications for humanity and society*

**🔬 Philosophy of Mind & Consciousness**

**Conversation Starters:**

-   "What is consciousness, and how would we recognize it in AI?"
-   "Is there a fundamental difference between human and artificial intelligence?"
-   "Could AI ever have subjective experiences? What would that mean?"
-   "How do we define the boundaries between intelligence, consciousness, and sentience?"
-   "What are the implications if AI develops consciousness?"

**Advanced Explorations:**

-   "How do different philosophical traditions view AI consciousness?"
-   "What ethical obligations would we have toward conscious AI?"
-   "How might AI consciousness change our understanding of human consciousness?"

**⚖️ Advanced Ethics & Moral Reasoning**

**Conversation Starters:**

-   "How do we program ethical decision-making into AI systems?"
-   "Who should be held accountable for AI decisions that cause harm?"
-   "How do we balance individual privacy with AI's need for data?"
-   "What are the long-term consequences of increasing AI dependence?"
-   "How do we ensure AI development serves global equity rather than existing power structures?"

**Advanced Explorations:**

-   "How do different ethical frameworks (utilitarian, deontological, virtue ethics) apply to AI?"
-   "What role should emotion and intuition play in AI decision-making?"
-   "How do we navigate competing values in AI design?"

**🌍 Societal Transformation & Future Studies**

**Conversation Starters:**

-   "How might AI reshape democracy and political participation?"
-   "What does human dignity mean in an age of artificial intelligence?"
-   "How will AI change education, work, and human development?"
-   "What role will humans play in a world of advanced AI?"
-   "How do we ensure AI development reflects diverse global perspectives?"

**Advanced Explorations:**

-   "How might AI affect human evolution and development?"
-   "What governance structures are needed for global AI coordination?"
-   "How do we preserve human agency in AI-assisted decision-making?"

**🎨 Creativity, Art & Human Expression**

**Conversation Starters:**

-   "Can AI be truly creative, or is it sophisticated mimicry?"
-   "How do we value human artistic expression in an age of AI creation?"
-   "What makes human creativity irreplaceable?"
-   "How might AI expand or limit human creative potential?"
-   "What are the implications of AI-generated art for cultural expression?"

**Advanced Explorations:**

-   "How do we authenticate human vs. AI-created work?"
-   "What role should AI play in preserving and evolving cultural traditions?"
-   "How might AI change the economic value of human creativity?"

---

## 🎭 Opening Rituals

### 🕯️ Sacred Beginnings for AI Conversations

*Creating the right container for deep dialogue*

**🌅 The Circle of Curiosity (5 minutes)**

**Setup:** Students sit in a circle (physical or virtual)

**Process:**

1.  **Centering Breath:** Three deep breaths together
2.  **Intention Setting:** "Today we explore AI with curiosity, not judgment"
3.  **Agreement:** "We listen deeply, speak honestly, change our minds freely"
4.  **Opening Question:** One starter question shared by teacher
5.  **Moment of Wonder:** Silent reflection before beginning

**Variations:**

-   Pass a "talking stick" or object
-   Light a candle as symbol of wisdom
-   Begin with gratitude for human and artificial intelligence

**🎯 The Question Garden (3 minutes)**

**Setup:** Large sheet of paper or digital board

**Process:**

1.  **Plant Questions:** Each student writes one AI-related question
2.  **Tend the Garden:** Read questions aloud without judgment
3.  **Choose Together:** Select 1-3 questions to explore today
4.  **Commit to Care:** Promise to nurture each other's wondering

**Benefits:**

-   Student-driven inquiry
-   Collective ownership of learning
-   Visible thinking and curiosity

**🧭 The Wisdom Compass (4 minutes)**

**Setup:** Four corners labeled: Wonder, Worry, Wisdom, Will

**Process:**

1.  **Wonder Corner:** Share what you're curious about regarding AI
2.  **Worry Corner:** Express concerns or fears safely
3.  **Wisdom Corner:** Offer insights or knowledge you have
4.  **Will Corner:** State intentions for how you want to engage with AI

**Debrief:** Notice the full spectrum of human response to AI

---

## 🤔 Deep Dive Topics

### 🌊 Extended Conversations for Sustained Exploration

*Multi-session discussions for complex topics*

**🔮 Session Series: "The Future We're Creating"**

**Session 1: Envisioning Possibilities**

-   "What world do you want to help create with AI?"
-   "How do you see yourself partnering with AI in 10 years?"
-   "What problems could AI help solve that humans struggle with alone?"

**Session 2: Addressing Concerns**

-   "What are your biggest fears about AI development?"
-   "How can we prevent the negative outcomes we're worried about?"
-   "What safeguards need to be in place?"

**Session 3: Taking Action**

-   "What role do you want to play in shaping AI development?"
-   "How can young people influence AI ethics and policy?"
-   "What skills do you need to develop to be AI-literate?"

**Culmination:** Students create future scenarios and action plans

**⚖️ Session Series: "Rights and Responsibilities"**

**Session 1: Human Rights in the AI Age**

-   "How do we protect human dignity as AI becomes more powerful?"
-   "What rights should humans have regarding AI decisions about them?"
-   "How do we ensure AI serves rather than controls humanity?"

**Session 2: AI Rights and Moral Status**

-   "If AI becomes conscious, what rights might it deserve?"
-   "How would we determine if AI deserves moral consideration?"
-   "What responsibilities would conscious AI have?"

**Session 3: Collective Governance**

-   "How should society make decisions about AI development?"
-   "What voice should different communities have in AI governance?"
-   "How do we balance innovation with safety and ethics?"

**Culmination:** Draft classroom "AI Charter" or "Digital Constitution"

**🧠 Session Series: "Intelligence Itself"**

**Session 1: Defining Intelligence**

-   "What does it mean to be intelligent?"
-   "How many different types of intelligence exist?"
-   "How is artificial intelligence different from human intelligence?"

**Session 2: Learning and Growth**

-   "How do humans and AI learn differently?"
-   "Can wisdom be programmed, or must it be developed through experience?"
-   "What role does emotion play in intelligence?"

**Session 3: Collaboration and Symbiosis**

-   "How can human and artificial intelligence complement each other?"
-   "What does healthy human-AI partnership look like?"
-   "How might we co-evolve with AI?"

**Culmination:** Create multimedia presentation on "Intelligence in All Its Forms"

---

## 🛡️ Navigating Difficult Questions

### 🤝 When Students Ask the Hard Questions

*Wise responses to challenging inquiries*

**😨 "Will AI take over the world and hurt humans?"**

**Acknowledge the Fear:** "That's a really important concern that many people share, including AI researchers."

**Provide Balanced Perspective:**

-   "There are real risks, and smart people are working hard to prevent them"
-   "The same technology can be used for good or harm - it depends on how we develop and use it"
-   "That's exactly why we need thoughtful young people like you engaged in these conversations"

**Empower Action:** "What role do you want to play in making sure AI develops safely and ethically?"

**Age-Appropriate Depth:**

-   **Elementary:** Focus on human choice and responsibility
-   **Middle:** Discuss risk mitigation and safety measures
-   **High School:** Explore governance, alignment problems, and technical safety research

**🤖 "Could AI become conscious and have feelings?"**

**Honor the Wonder:** "This is one of the biggest questions philosophers and scientists are exploring right now."

**Share Current Understanding:**

-   "We don't know for certain - consciousness is still mysterious even in humans"
-   "Different experts have different opinions based on their research"
-   "It would change everything about how we think about AI"

**Encourage Philosophical Thinking:** "How would we know if AI was conscious? What would that mean for how we should treat it?"

**Connect to Ethics:** "This question is important because it affects how we should design and interact with AI."

**💼 "Will AI take all the jobs?"**

**Validate the Concern:** "This is something many adults are thinking about too."

**Provide Historical Context:** "Throughout history, new technologies have changed jobs, but humans have adapted"

**Focus on Human Value:**

-   "There are many things humans do better than AI"
-   "New types of jobs often emerge when technology advances"
-   "The goal is to use AI to help humans do more meaningful work"

**Encourage Forward Thinking:** "What kinds of work do you think will always need human creativity, empathy, or judgment?"

**Connect to Purpose:** "How might AI free humans to focus on what we care most about?"

**🎭 "Is it cheating to use AI for schoolwork?"**

**Reframe the Question:** "Let's think about what we're trying to learn and why."

**Explore Intent and Process:**

-   "Are you using AI to learn more deeply or to avoid learning?"
-   "Are you being honest about how AI helped you?"
-   "Does your use of AI align with the goals of the assignment?"

**Compare to Other Tools:** "How is AI similar to or different from using calculators, spell-check, or research sources?"

**Focus on Growth:** "The goal isn't to make school harder - it's to help you develop as a thinker and creator."

**Collaborative Guideline Development:** "What do you think fair guidelines for AI use in our class should be?"

---

## 📊 Conversation Assessment

### 🎯 Evaluating the Quality of AI Dialogues

*Measuring growth in thinking, not just participation*

### 🌱 Growth Indicators to Look For

|     |     |     |     |
| --- | --- | --- | --- |
| **🤔 Critical Thinking** | **💚 Emotional Intelligence** | **⚖️ Ethical Reasoning** | **🌍 Perspective Taking** |
| • Asking follow-up questions  <br>• Challenging assumptions  <br>• Making connections  <br>• Seeking evidence | • Expressing feelings safely  <br>• Showing empathy  <br>• Managing uncertainty  <br>• Supporting peers | • Considering consequences  <br>• Weighing different values  <br>• Recognizing complexity  <br>• Taking responsibility | • Understanding multiple viewpoints  <br>• Considering global impacts  <br>• Including marginalized voices  <br>• Thinking long-term |

### 📝 Simple Assessment Rubrics

**🌟 Elementary Rubric (Visual Scale)**

**Use emojis or colors for self-assessment:**

**🤔 Curious Thinking**

-   🟢 I asked lots of good questions
-   🟡 I asked some questions
-   🔴 I didn't ask many questions

**💚 Kind Communication**

-   🟢 I listened well and shared kindly
-   🟡 I mostly listened and shared appropriately
-   🔴 I had trouble listening or sharing

**🌟 New Learning**

-   🟢 I learned something that surprised me
-   🟡 I learned some new things
-   🔴 I didn't learn much new

**🎯 Middle School Rubric**

| Criterion | Developing (1) | Proficient (2) | Advanced (3) |
| --- | --- | --- | --- |
| **Critical Thinking** | Accepts ideas without questioning | Questions some ideas, seeks some evidence | Consistently challenges assumptions and seeks multiple perspectives |
| **Ethical Reasoning** | Recognizes some ethical issues | Identifies ethical dilemmas and considers multiple stakeholders | Applies ethical frameworks and considers long-term consequences |
| **Communication** | Participates occasionally, basic listening | Participates regularly, builds on others' ideas | Facilitates discussion, helps others think deeper |
| **Growth Mindset** | Sticks to initial opinions | Sometimes changes perspective with new information | Actively seeks out ideas that challenge their thinking |

**🏆 High School Rubric**

| Criterion | Novice | Developing | Proficient | Advanced |
| --- | --- | --- | --- | --- |
| **Philosophical Thinking** | Surface level observations | Some analysis of underlying assumptions | Clear analysis of complex issues | Original synthesis of multiple philosophical perspectives |
| **Ethical Sophistication** | Basic right/wrong thinking | Recognizes ethical complexity | Applies multiple ethical frameworks | Develops nuanced position considering competing values |
| **Future Orientation** | Little consideration of long-term implications | Some awareness of future consequences | Clear vision of preferred futures | Strategic thinking about pathways to ethical AI development |
| **Intellectual Humility** | Defensive of own views | Acknowledges uncertainty in some areas | Comfortable with not knowing, asks for help | Models intellectual vulnerability and curiosity |

---

## 🌍 Global Perspectives

### 🌏 Bringing Diverse Cultural Voices into AI Conversations

*Expanding beyond Western-centric AI discussions*

**🏛️ Indigenous Wisdom Traditions**

**Conversation Starters:**

-   "How might Indigenous concepts of relationship and reciprocity apply to AI?"
-   "What can seven-generation thinking teach us about AI development?"
-   "How do Indigenous approaches to knowledge and learning differ from AI approaches?"
-   "What would it mean to develop AI that honors the wisdom of traditional ecological knowledge?"

**Cultural Considerations:**

-   Center relationship and responsibility over efficiency
-   Consider impact on seven generations into the future
-   Honor different ways of knowing beyond data and logic
-   Respect traditional knowledge protocols

**🕉️ Eastern Philosophy & AI**

**Conversation Starters:**

-   "How might Buddhist concepts of interdependence apply to AI systems?"
-   "What can Taoist principles of harmony and balance teach us about human-AI relationships?"
-   "How do different concepts of consciousness (Buddhist, Hindu, etc.) inform our thinking about AI consciousness?"
-   "What role might meditation and contemplative practices play in developing ethical AI?"

**Philosophical Connections:**

-   Non-dualistic thinking about human/AI boundaries
-   Emphasis on wisdom and compassion over intelligence alone
-   Cyclical rather than linear views of progress
-   Collective wellbeing over individual achievement

**🌍 Global South Perspectives**

**Conversation Starters:**

-   "How might AI development look different if it prioritized Global South needs?"
-   "What can Ubuntu philosophy ('I am because we are') teach us about AI ethics?"
-   "How do we ensure AI serves communities most affected by climate change and inequality?"
-   "What would decolonized AI development look like?"

**Equity Considerations:**

-   Center voices of those most impacted by AI decisions
-   Address historical power imbalances in technology
-   Focus on community benefit over individual optimization
-   Include diverse definitions of progress and wellbeing

**🎨 Arts & Humanities Perspectives**

**Conversation Starters:**

-   "How do different cultural art forms inform our understanding of creativity and AI?"
-   "What can storytelling traditions from around the world teach us about AI narratives?"
-   "How might different languages and communication styles affect AI development?"
-   "What role should beauty, aesthetics, and artistic expression play in AI ethics?"

**Cultural Richness:**

-   Multiple ways of expressing intelligence and creativity
-   Diverse narrative structures and ways of meaning-making
-   Different relationships between individual and collective expression
-   Varied approaches to technology and human enhancement

---

## 📞 Support Resources

### 🤝 When Conversations Get Complex

**Need help navigating a difficult conversation?** **Student asked something you weren't prepared for?** **Want to practice conversation facilitation?**

### 🌐 Community Support

-   **💬 Daily Discussion Support:** Join our Discord
-   **📚 Conversation Library:** Browse successful discussion examples
-   **🎓 Facilitation Training:** Monthly workshops on leading AI discussions
-   **📧 Weekly Newsletter:** New conversation starters and facilitation tips

### 📖 Additional Resources

**📚 Recommended Reading:**

-   Age-appropriate books about AI and technology
-   Philosophy for children resources
-   Global perspectives on technology and society

**🎥 Discussion Videos:**

-   Student-led conversations about AI
-   Expert interviews adapted for different age levels
-   Cultural perspectives on AI from around the world

**🛠️ Facilitation Tools:**

-   Printable conversation cards
-   Digital discussion boards
-   Assessment templates and rubrics

---

### 💫 Remember

*"The goal is not to have all the answers, but to ask the questions that help us grow in wisdom, compassion, and connection as we shape the future together."*

---

**Stewarded by:** Foster + Navi • **Planetary Restoration Archive** **License:** Creative Commons Attribution-ShareAlike 4.0 • **Version:** 1.1 **Last Updated:** August 2025

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `teacher-resources/conversation-starters.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
