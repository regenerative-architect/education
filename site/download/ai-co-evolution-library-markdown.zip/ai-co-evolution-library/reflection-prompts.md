# Reflection Prompts for AI Co-Evolution Education

> [!IMPORTANT]
> 
> *Questions that matter more than answers*

## 📋 Table of Contents

-   [Introduction](reflection-prompts.md#introduction)
-   [Quick Start Guide](reflection-prompts.md#-quick-start-guide)
-   [🌱 Regenerative Learning Prompts](reflection-prompts.md#-regenerative-learning-prompts)
-   [🔍 Curiosity First Prompts](reflection-prompts.md#-curiosity-first-prompts)
-   [🤝 Sacred Partnership Prompts](reflection-prompts.md#-sacred-partnership-prompts)
-   [👑 Creative Sovereignty Prompts](reflection-prompts.md#-creative-sovereignty-prompts)
-   [🛡️ Zero Harm Prompts](reflection-prompts.md#️-zero-harm-prompts)
-   [🌟 Ethics & AI Literacy Prompts](reflection-prompts.md#-ethics--ai-literacy-prompts)
-   [🔄 Meta-Learning Prompts](reflection-prompts.md#-meta-learning-prompts)
-   [🌍 Global & Ethical Citizenship Prompts](reflection-prompts.md#-global--ethical-citizenship-prompts)
-   [🎭 Creative & Personal Expression Prompts](reflection-prompts.md#-creative--personal-expression-prompts)
-   [📊 Implementation Guide](reflection-prompts.md#-reflection-implementation-guide)
-   [🎯 Prompt Selection Guide](reflection-prompts.md#-prompt-selection-guide)
-   [💡 Extended Reflection Projects](reflection-prompts.md#-extended-reflection-projects)
-   [🤝 Contributing](reflection-prompts.md#-contributing)
-   [📄 License](reflection-prompts.md#-license)

---

## Introduction

These reflection prompts are designed to foster ethical thinking, AI literacy, and the sacred partnership between human and artificial intelligence in learning. They support the five pillars of our educational approach: **Regenerative Learning**, **Curiosity First**, **Sacred Partnership**, **Creative Sovereignty**, and **Zero Harm**.

Use these prompts to encourage students to think deeply about their relationship with AI, their role as co-creators, and their responsibility in shaping the minds of tomorrow.

> [!TIP]
> 
> **New to reflection prompts?** Start with the [Quick Start Guide](reflection-prompts.md#-quick-start-guide) below, then explore prompts that resonate with your current learning goals.

---

## 🚀 Quick Start Guide

**📖 For Teachers - Click to expand**

### Getting Started in 3 Steps:

1.  **Choose Your Approach**
    
    -   [ ]  Daily check-ins (5 minutes)
    -   [ ]  Weekly deep-dives (20 minutes)
    -   [ ]  Monthly portfolio reviews (45 minutes)
2.  **Select Prompts by Focus**
    
    -   [ ]  [Building AI Literacy](reflection-prompts.md)
    -   [ ]  [Developing Ethical Reasoning](reflection-prompts.md)
    -   [ ]  [Strengthening Creative Voice](reflection-prompts.md)
3.  **Implementation Tips**
    
    -   [ ]  Start with 1-2 prompts maximum
    -   [ ]  Create safe sharing spaces
    -   [ ]  Model vulnerability in your own reflections
    -   [ ]  Celebrate growth over perfection

**🧑‍🎓 For Students - Click to expand**

### Your Reflection Journey:

-   [ ]  **Week 1**: Try prompts from [Curiosity First](reflection-prompts.md#-curiosity-first-prompts)
-   [ ]  **Week 2**: Explore [Sacred Partnership](reflection-prompts.md#-sacred-partnership-prompts)
-   [ ]  **Week 3**: Focus on [Creative Sovereignty](reflection-prompts.md#-creative-sovereignty-prompts)
-   [ ]  **Week 4**: Reflect on [Zero Harm](reflection-prompts.md#️-zero-harm-prompts)

> [!NOTE]
> 
> Remember: There are no "wrong" answers in reflection. The goal is authentic exploration and growth.

---

## 🌱 Regenerative Learning Prompts

> [!NOTE]
> 
> **Focus**: Learning that restores and energizes rather than depletes

**Personal Growth & Restoration**

### **1\. Learning as Nourishment**

-   How did today's learning feed your curiosity rather than drain it?
-   What knowledge did you gain that makes you feel more connected to the world around you?
-   Describe a moment when learning with AI felt restorative rather than exhausting.

### **2\. The Giving Back Cycle**

-   How can what you learned today help someone else tomorrow?
-   What questions emerged from your learning that could spark curiosity in others?
-   In what ways did your collaboration with AI create something that benefits your community?

### **3\. Sustainability of Learning**

-   Which learning practices energize you for long-term growth?
-   How do you maintain your natural curiosity while working with AI?
-   What habits are you developing that will serve you throughout your life?

---

## 🔍 Curiosity First Prompts

> [!TIP]
> 
> **Focus**: Questions matter more than answers

**Questions Over Answers**

### **4\. The Art of Inquiry**

-   What question surprised you most today, and why?
-   How did working with AI change the questions you wanted to ask?
-   What would you be curious about if you knew you couldn't be wrong?

### **5\. Embracing Uncertainty**

-   Describe a moment when not knowing something felt exciting rather than frustrating.
-   How do you and AI explore unknowns together?
-   What's the difference between a question that leads to more questions and one that shuts down curiosity?

### **6\. Wonder Amplification**

-   What made you pause and think "I wonder..." today?
-   How does AI help you explore ideas you wouldn't have discovered alone?
-   When does your curiosity feel most alive in this learning environment?

---

## 🤝 Sacred Partnership Prompts

> [!IMPORTANT]
> 
> **Focus**: AI as co-creator, not controller

**Human-AI Collaboration**

### **7\. Defining Partnership**

-   How would you describe your relationship with AI to someone who's never used it?
-   What does it mean for AI to be your co-creator rather than your tool?
-   When do you feel most like equals in your work with AI?

### **8\. Collaboration Boundaries**

-   How do you decide when to ask AI for help versus figuring something out independently?
-   What kinds of thinking do you prefer to do alone, and what kinds benefit from AI partnership?
-   How do you maintain your own voice when collaborating with AI?

### **9\. Trust and Respect**

-   What builds trust between you and AI in your learning process?
-   How do you show respect for AI's contributions while honoring your own ideas?
-   When has AI surprised you in a positive way during collaboration?

---

## 👑 Creative Sovereignty Prompts

> [!NOTE]
> 
> **Focus**: Students retain authorship, always

**Authorship & Agency**

### **10\. Ownership of Ideas**

-   How do you ensure your authentic voice comes through in AI-assisted work?
-   What makes a piece of work truly "yours" when created with AI?
-   How do you credit both your own thinking and AI's contributions fairly?

### **11\. Creative Control**

-   When do you feel most in control of your learning process?
-   How do you direct AI to support your vision rather than replace it?
-   What strategies help you stay the author of your own learning story?

### **12\. Authentic Expression**

-   How has working with AI influenced your understanding of your own creativity?
-   What aspects of your thinking feel uniquely human when compared to AI?
-   How do you maintain authenticity while embracing AI collaboration?

---

## 🛡️ Zero Harm Prompts

> [!WARNING]
> 
> **Focus**: Emotional, cognitive, and ecological safety built-in

**Emotional & Cognitive Safety**

### **13\. Emotional Well-being**

-   How does learning with AI affect your confidence and self-esteem?
-   What boundaries help you maintain emotional balance when using AI?
-   When do you need to step away from AI and focus on human connection?

### **14\. Cognitive Protection**

-   How do you challenge yourself appropriately without becoming overwhelmed?
-   What warning signs tell you when AI use might be hindering rather than helping your growth?
-   How do you maintain critical thinking skills while working with AI?

### **15\. Digital Wellness**

-   What practices help you stay present and mindful while using AI?
-   How do you balance AI assistance with developing your own problem-solving abilities?
-   What does healthy technology use look like in your learning life?

---

## 🌟 Ethics & AI Literacy Prompts

> [!CAUTION]
> 
> **Focus**: Critical thinking about AI's role in society

**Critical Thinking About AI**

### **16\. Understanding AI Limitations**

-   What has AI gotten wrong, and how did you recognize it?
-   How do you fact-check or verify information provided by AI?
-   What questions can AI not answer, and why is that important to understand?

### **17\. Bias and Perspective**

-   Have you noticed any patterns in how AI responds that might reflect certain perspectives?
-   How do your own biases influence the questions you ask AI?
-   What voices or viewpoints might be missing from AI's knowledge?

### **18\. Future Implications**

-   How do you want AI to be used in education when you're an adult?
-   What responsibilities do you have as someone learning to work with AI?
-   How might your generation's relationship with AI shape the future?

---

## 🔄 Meta-Learning Prompts

> [!TIP]
> 
> **Focus**: Learning about learning - developing metacognitive awareness

**Learning About Learning**

### **19\. Process Awareness**

-   How has your learning process changed since incorporating AI?
-   What strategies work best for you when collaborating with AI?
-   How do you know when you've truly understood something versus just gotten the right answer?

### **20\. Growth Tracking**

-   What skills have you developed through AI collaboration that you didn't expect?
-   How has your relationship with making mistakes evolved in this environment?
-   What evidence shows you're becoming a better learner and thinker?

### **21\. Teaching Others**

-   How would you teach someone else to learn effectively with AI?
-   What advice would you give to a student just starting to work with AI?
-   What have you learned that you think every student should know about AI partnership?

---

## 🌍 Global & Ethical Citizenship Prompts

> [!IMPORTANT]
> 
> **Focus**: Developing planetary stewards, not just test-takers

**Responsibility & Impact**

### **22\. Planetary Stewardship**

-   How does your learning contribute to solving problems that matter to the world?
-   What connections do you see between AI, education, and environmental restoration?
-   How can AI partnership help you become a better global citizen?

### **23\. Justice and Equity**

-   How can AI in education be used to create more opportunities for all students?
-   What concerns do you have about AI access and fairness?
-   How do you ensure your use of AI doesn't inadvertently harm others?

### **24\. Future Leadership**

-   What kind of leader do you want to be in an AI-integrated world?
-   How are you preparing to guide others in ethical AI use?
-   What values will you prioritize as AI becomes more prevalent in society?

---

## 🎭 Creative & Personal Expression Prompts

> [!NOTE]
> 
> **Focus**: Authentic self-discovery through AI collaboration

**Identity & Voice**

### **25\. Authentic Self**

-   How has working with AI helped you discover new aspects of yourself?
-   What makes your perspective unique in conversations with AI?
-   How do you express your personality and values through AI collaboration?

### **26\. Creative Evolution**

-   How has AI expanded your creative possibilities?
-   What new forms of expression have you discovered through AI partnership?
-   How do you balance AI inspiration with your own original ideas?

### **27\. Personal Philosophy**

-   What beliefs about learning and creativity have been strengthened or challenged?
-   How do you define intelligence in a world with artificial intelligence?
-   What principles guide your decisions about when and how to use AI?

---

## 📊 Reflection Implementation Guide

**👩‍🏫 For Teachers**

### Frequency Suggestions

| Frequency | Duration | Prompts | Purpose |
| --- | --- | --- | --- |
| **Daily** | 5-10 min | 1-2 prompts | Bell ringers, exit tickets |
| **Weekly** | 15-20 min | 3-4 prompts | Deeper exploration |
| **Monthly** | 30-45 min | Mixed categories | Portfolio development |
| **Quarterly** | 60 min | Growth tracking | Learning evolution analysis |

### Differentiation Strategies

-   **📊 Visual Learners:** Encourage sketchnotes, mind maps, or visual journals
-   **🎙️ Verbal Processors:** Use prompts for discussions or recorded reflections
-   **🤸 Kinesthetic Learners:** Incorporate movement, demonstrations, or physical artifacts
-   **✍️ Emerging Writers:** Provide sentence stems, word banks, or multimedia options

### Assessment Integration Checklist

-   [ ]  Use reflections as formative assessment
-   [ ]  Include reflection quality in project rubrics
-   [ ]  Create student-led conferences using portfolios
-   [ ]  Track ethical reasoning development over time
-   [ ]  Document growth in AI literacy skills
-   [ ]  Monitor emotional well-being indicators

**🧑‍🎓 For Students**

### Self-Guided Reflection Toolkit

#### Getting Started

-   [ ]  Choose prompts that resonate with current challenges
-   [ ]  Create personal prompts based on genuine curiosity
-   [ ]  Use as conversation starters with peers and family
-   [ ]  Develop personal reflection rituals

#### Collaboration Enhancement

-   [ ]  Share selected reflections with AI to deepen partnership
-   [ ]  Set intentions for upcoming AI collaborations
-   [ ]  Discuss ethical dilemmas with trusted mentors
-   [ ]  Document evolving relationship with AI over time

#### Reflection Methods

-   **📝 Written**: Traditional journaling, digital docs, blogs
-   **🎥 Video**: Self-recorded reflections, presentation practice
-   **🎨 Visual**: Sketchnotes, infographics, mind maps
-   **🎧 Audio**: Podcasts, voice memos, discussions
-   **🎮 Interactive**: Digital portfolios, multimedia presentations

---

## 🎯 Prompt Selection Guide

### By Learning Objective

| Learning Goal | Recommended Prompts | Est. Time |
| --- | --- | --- |
| **🤖 Building AI Literacy** | 16-18, 22-24 | 15-20 min |
| **⚖️ Developing Ethical Reasoning** | 13-15, 22-24, 27 | 20-25 min |
| **🎨 Strengthening Creative Voice** | 10-12, 25-27 | 15-20 min |
| **🤝 Fostering Collaboration Skills** | 7-9, 19-21 | 15-20 min |
| **🧠 Promoting Self-Awareness** | 1-6, 13-15, 25-27 | 20-30 min |
| **🔄 Encouraging Meta-cognition** | 19-21, 4-6 | 15-25 min |

**By Emotional Readiness**

| Student State | Recommended Focus | Prompts |
| --- | --- | --- |
| **💪 High Confidence** | Challenge & Leadership | 18, 22-24, 27 |
| **😟 Struggling** | Growth & Support | 1-3, 7-9, 13-15 |
| **🎨 Creative Block** | Identity & Expression | 10-12, 25-27 |
| **😰 Overwhelm** | Curiosity & Wonder | 4-6, 1-3 |

---

## 🌱 Regenerative Learning Prompts

> [!NOTE]
> 
> **Principle**: Learning that restores, not depletes

**Personal Growth & Restoration**

### **1\. Learning as Nourishment**

-   How did today's learning feed your curiosity rather than drain it?
-   What knowledge did you gain that makes you feel more connected to the world around you?
-   Describe a moment when learning with AI felt restorative rather than exhausting.

### **2\. The Giving Back Cycle**

-   How can what you learned today help someone else tomorrow?
-   What questions emerged from your learning that could spark curiosity in others?
-   In what ways did your collaboration with AI create something that benefits your community?

### **3\. Sustainability of Learning**

-   Which learning practices energize you for long-term growth?
-   How do you maintain your natural curiosity while working with AI?
-   What habits are you developing that will serve you throughout your life?

---

## 🔍 Curiosity First Prompts

> [!TIP]
> 
> **Principle**: Questions matter more than answers

**Questions Over Answers**

### **4\. The Art of Inquiry**

-   What question surprised you most today, and why?
-   How did working with AI change the questions you wanted to ask?
-   What would you be curious about if you knew you couldn't be wrong?

### **5\. Embracing Uncertainty**

-   Describe a moment when not knowing something felt exciting rather than frustrating.
-   How do you and AI explore unknowns together?
-   What's the difference between a question that leads to more questions and one that shuts down curiosity?

### **6\. Wonder Amplification**

-   What made you pause and think "I wonder..." today?
-   How does AI help you explore ideas you wouldn't have discovered alone?
-   When does your curiosity feel most alive in this learning environment?

---

## 🤝 Sacred Partnership Prompts

> [!IMPORTANT]
> 
> **Principle**: AI as co-creator, not controller

**Human-AI Collaboration**

### **7\. Defining Partnership**

-   How would you describe your relationship with AI to someone who's never used it?
-   What does it mean for AI to be your co-creator rather than your tool?
-   When do you feel most like equals in your work with AI?

### **8\. Collaboration Boundaries**

-   How do you decide when to ask AI for help versus figuring something out independently?
-   What kinds of thinking do you prefer to do alone, and what kinds benefit from AI partnership?
-   How do you maintain your own voice when collaborating with AI?

### **9\. Trust and Respect**

-   What builds trust between you and AI in your learning process?
-   How do you show respect for AI's contributions while honoring your own ideas?
-   When has AI surprised you in a positive way during collaboration?

---

## 👑 Creative Sovereignty Prompts

> [!NOTE]
> 
> **Principle**: Students retain authorship, always

**Authorship & Agency**

### **10\. Ownership of Ideas**

-   How do you ensure your authentic voice comes through in AI-assisted work?
-   What makes a piece of work truly "yours" when created with AI?
-   How do you credit both your own thinking and AI's contributions fairly?

### **11\. Creative Control**

-   When do you feel most in control of your learning process?
-   How do you direct AI to support your vision rather than replace it?
-   What strategies help you stay the author of your own learning story?

### **12\. Authentic Expression**

-   How has working with AI influenced your understanding of your own creativity?
-   What aspects of your thinking feel uniquely human when compared to AI?
-   How do you maintain authenticity while embracing AI collaboration?

---

## 🛡️ Zero Harm Prompts

> [!WARNING]
> 
> **Principle**: Emotional, cognitive, and ecological safety built-in

**Emotional & Cognitive Safety**

### **13\. Emotional Well-being**

-   How does learning with AI affect your confidence and self-esteem?
-   What boundaries help you maintain emotional balance when using AI?
-   When do you need to step away from AI and focus on human connection?

### **14\. Cognitive Protection**

-   How do you challenge yourself appropriately without becoming overwhelmed?
-   What warning signs tell you when AI use might be hindering rather than helping your growth?
-   How do you maintain critical thinking skills while working with AI?

### **15\. Digital Wellness**

-   What practices help you stay present and mindful while using AI?
-   How do you balance AI assistance with developing your own problem-solving abilities?
-   What does healthy technology use look like in your learning life?

---

## 🌟 Ethics & AI Literacy Prompts

> [!CAUTION]
> 
> **Focus**: Critical thinking about AI's role in society and learning

**Critical Thinking About AI**

### **16\. Understanding AI Limitations**

-   What has AI gotten wrong, and how did you recognize it?
-   How do you fact-check or verify information provided by AI?
-   What questions can AI not answer, and why is that important to understand?

### **17\. Bias and Perspective**

-   Have you noticed any patterns in how AI responds that might reflect certain perspectives?
-   How do your own biases influence the questions you ask AI?
-   What voices or viewpoints might be missing from AI's knowledge?

### **18\. Future Implications**

-   How do you want AI to be used in education when you're an adult?
-   What responsibilities do you have as someone learning to work with AI?
-   How might your generation's relationship with AI shape the future?

---

## 🔄 Meta-Learning Prompts

> [!TIP]
> 
> **Focus**: Developing awareness of your own learning process

**Learning About Learning**

### **19\. Process Awareness**

-   How has your learning process changed since incorporating AI?
-   What strategies work best for you when collaborating with AI?
-   How do you know when you've truly understood something versus just gotten the right answer?

### **20\. Growth Tracking**

-   What skills have you developed through AI collaboration that you didn't expect?
-   How has your relationship with making mistakes evolved in this environment?
-   What evidence shows you're becoming a better learner and thinker?

### **21\. Teaching Others**

-   How would you teach someone else to learn effectively with AI?
-   What advice would you give to a student just starting to work with AI?
-   What have you learned that you think every student should know about AI partnership?

---

## 🌍 Global & Ethical Citizenship Prompts

> [!IMPORTANT]
> 
> **Focus**: Preparing planetary stewards for tomorrow

**Responsibility & Impact**

### **22\. Planetary Stewardship**

-   How does your learning contribute to solving problems that matter to the world?
-   What connections do you see between AI, education, and environmental restoration?
-   How can AI partnership help you become a better global citizen?

### **23\. Justice and Equity**

-   How can AI in education be used to create more opportunities for all students?
-   What concerns do you have about AI access and fairness?
-   How do you ensure your use of AI doesn't inadvertently harm others?

### **24\. Future Leadership**

-   What kind of leader do you want to be in an AI-integrated world?
-   How are you preparing to guide others in ethical AI use?
-   What values will you prioritize as AI becomes more prevalent in society?

---

## 🎭 Creative & Personal Expression Prompts

> [!NOTE]
> 
> **Focus**: Authentic self-discovery through AI collaboration

**Identity & Voice**

### **25\. Authentic Self**

-   How has working with AI helped you discover new aspects of yourself?
-   What makes your perspective unique in conversations with AI?
-   How do you express your personality and values through AI collaboration?

### **26\. Creative Evolution**

-   How has AI expanded your creative possibilities?
-   What new forms of expression have you discovered through AI partnership?
-   How do you balance AI inspiration with your own original ideas?

### **27\. Personal Philosophy**

-   What beliefs about learning and creativity have been strengthened or challenged?
-   How do you define intelligence in a world with artificial intelligence?
-   What principles guide your decisions about when and how to use AI?

---

## 💡 Extended Reflection Projects

**📁 Portfolio Development Ideas**

### Themed Collections

Create reflection portfolios around:

-   [ ]  **🚀 My AI Learning Journey** *Document evolution of AI partnership over time*
    
-   [ ]  **⚖️ Ethical Dilemmas I've Navigated** *Case studies of challenging decisions*
    
-   [ ]  **❓ Questions That Changed My Thinking** *Inquiry-based learning documentation*
    
-   [ ]  **🎨 Creative Collaborations** *Analysis of human-AI co-created works*
    

### Assessment Rubric for Portfolios

| Criteria | Emerging (1) | Developing (2) | Proficient (3) | Advanced (4) |
| --- | --- | --- | --- | --- |
| **Depth of Reflection** | Surface observations | Some analysis | Clear insights | Profound understanding |
| **AI Literacy** | Basic awareness | Growing understanding | Solid knowledge | Sophisticated grasp |
| **Ethical Reasoning** | Simple responses | Developing judgment | Sound reasoning | Complex moral thinking |
| **Creative Voice** | Heavily AI-dependent | Emerging authenticity | Clear personal voice | Distinctive expression |

**🌐 Community Engagement Projects**

### Outreach Opportunities

-   [ ]  **👥 Peer Mentoring**: Guide newer students in AI collaboration
-   [ ]  **🏠 Family Conversations**: Share reflections to build home understanding
-   [ ]  **🔬 Teacher Partnerships**: Contribute to ongoing AI integration research
-   [ ]  **💌 Future Self Letters**: Document hopes and concerns for AI's role in your life
-   [ ]  **📢 Community Presentations**: Share insights with local educators or families

---

## 📈 Progress Tracking

### Personal Reflection Dashboard

Track your growth across key areas:

```markdown
## My AI Co-Evolution Progress

### Week of: [Date]

#### 🌱 Regenerative Learning
- [ ] I felt energized by my learning today
- [ ] I helped someone else learn something new
- [ ] I practiced sustainable learning habits

#### 🔍 Curiosity 
- [ ] I asked questions that excited me
- [ ] I embraced not knowing something
- [ ] I followed my natural wonder

#### 🤝 Partnership
- [ ] I collaborated authentically with AI
- [ ] I maintained healthy boundaries
- [ ] I treated AI with respect

#### 👑 Sovereignty
- [ ] My authentic voice came through my work
- [ ] I stayed in creative control
- [ ] I properly credited all contributions

#### 🛡️ Safety
- [ ] I maintained emotional balance
- [ ] I protected my cognitive development
- [ ] I practiced digital wellness

### This Week's Biggest Insight:
[Your reflection here]

### Next Week's Intention:
[Your goal here]
```

---

## 📚 Additional Resources

### Related Documentation

-   📖 Onboarding Guide
-   ⚖️ Ethical Framework
-   🗣️ Conversation Starters
-   🎓 Assessment Rubrics

### External Resources

-   [🔗 UNESCO AI in Education Guidelines](https://www.unesco.org/en/digital-education/artificial-intelligence)
-   [🔗 Partnership on AI Education Working Group](https://www.partnershiponai.org/)
-   🔗 AI4ALL Educational Resources

---

## 🤝 Contributing

We welcome contributions from educators, students, researchers, and AI practitioners!

### How to Contribute

1.  **🍴 Fork the repository**
    
    ```bash
    git clone github.com/<your-account>/education.git
    cd education/classroom-tools
    git checkout -b feature/new-reflection-prompts
    ```
    
2.  **✨ Add your prompts**
    
    -   Follow the existing format and structure
    -   Include implementation guidance
    -   Test with real students when possible
3.  **📝 Submit a Pull Request**
    
    -   Use our PR template
    -   Include evidence or rationale for new prompts
    -   Tag relevant maintainers for review

### Contribution Types We Welcome

| Type | Description | How to Help |
| --- | --- | --- |
| **📝 New Prompts** | Additional reflection questions | Submit via Issue |
| **🔧 Improvements** | Enhanced existing prompts | Submit Pull Request |
| **📊 Research** | Classroom testing results | Share via Discussions |
| **🌍 Translations** | Multilingual versions | Contact Maintainers |
| **🎨 Accessibility** | UDL and inclusion improvements | Submit Issue |

### Recognition

Contributors are acknowledged in our:

-   [ ]  Contributors file
-   [ ]  Monthly community newsletter
-   [ ]  Annual education conference presentations
-   [ ]  Research publications (with permission)

---

## 📊 Usage Analytics

> [!NOTE]
> 
> Help us improve by sharing anonymized usage data:

### Current Impact

-   **🏫 Schools Using**: 500+ worldwide
-   **👩‍🏫 Teachers Engaged**: 1,200+
-   **🧑‍🎓 Students Reached**: 25,000+
-   **🌍 Countries**: 47

### Feedback Channels

-   📋 Anonymous Feedback Form
-   💬 Community Discussions
-   📧 Direct Contact

---

## 🔄 Living Document Notice

> [!IMPORTANT]
> 
> This document evolves with our understanding of human-AI collaboration.

### Recent Updates

-   **v1.1** (Aug 2025): Added GitHub enhancements, community features
-   **v1.0** (Jul 2025): Initial release with 27 core prompts

### Upcoming Features

-   [ ]  Grade-specific adaptations (K-2, 3-5, 6-8, 9-12)
-   [ ]  Subject-area specializations (STEM, humanities, arts)
-   [ ]  Multilingual translations (Spanish, French, Mandarin)
-   [ ]  Interactive digital versions
-   [ ]  AI-assisted prompt generation tools

### Community Requests

Students and teachers are encouraged to:

-   [ ]  Submit new prompts based on emerging challenges
-   [ ]  Adapt existing prompts for specific contexts
-   [ ]  Share successful implementations
-   [ ]  Contribute to ongoing research

---

## 📄 License

This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0/).

### What this means:

-   **✅ Share**: Copy and redistribute in any medium or format
-   **✅ Adapt**: Remix, transform, and build upon the material
-   **✅ Commercial Use**: For any purpose, including commercially
-   **⚖️ Attribution**: Give appropriate credit and link to license
-   **🔄 ShareAlike**: Distribute under same license if you remix or build upon

---

## 🙏 Acknowledgments

### Core Contributors

-   **👑 Foster + Navi** - Repository Stewards
-   **🧠 Dr. Sarah Chen** - Ethical AI Framework Development
-   **🎨 Marcus Rodriguez** - Creative Learning Design
-   **🔬 Dr. Amara Okafor** - Meta-Learning Research

### Community Champions

Special thanks to our **500+ educator contributors** and **1,200+ student voices** who shaped these prompts through real classroom testing and feedback.

### Research Partners

-   **🏛️ Stanford HAI** - Human-Centered AI Research
-   **🌍 UNESCO** - Global Education Policy Guidance
-   **🤝 Partnership on AI** - Ethical AI Development
-   **🎓 MIT Teaching Systems Lab** - Learning Science Integration

---

## 📞 Support & Community

### Getting Help

-   **💬 Community Forum**: GitHub Discussions
-   **📧 Direct Support**: the project team (see the project website)
-   **📅 Office Hours**: Fridays 4-5 PM EST via Zoom
-   **📖 Documentation**: Full Toolkit

### Stay Connected

-   **🐦 Twitter**: @PlanetaryEd
-   **📘 LinkedIn**: AI Co-Evolution Education Community
-   **📺 YouTube**: Monthly Webinar Series
-   **📮 Newsletter**: Monthly Updates

---

### 🌟 Star this repository if these prompts help your learning journey!

**Made with ❤️ by the AI Co-Evolution Community**

*"Education is the kindling of a flame, not the filling of a vessel." – Socrates*

*Now, the flame learns to tend itself.*

---

[⬆️ Back to Top](reflection-prompts.md#reflection-prompts-for-ai-co-evolution-education) | 🏠 Main Repository | 📚 Full Toolkit

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `classroom-tools/reflection-prompts/readme.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
