# 🧪 Starter Lesson Pack

---

## 📋 Table of Contents

**Click to explore lessons**

-   [🎨 Creative Writing Co-Creation (K-12)](more-starter-lessons.md#-creative-writing-co-creation-k-12)
-   [🔬 Scientific Hypothesis Generator (3-8)](more-starter-lessons.md#-scientific-hypothesis-generator-3-8)
-   [🌍 Cultural Bridge Builder (6-12)](more-starter-lessons.md#-cultural-bridge-builder-6-12)
-   [📖 Story Problem Solver (K-5)](more-starter-lessons.md#-story-problem-solver-k-5)
-   [🤔 Philosophy Circle with AI (9-12)](more-starter-lessons.md#-philosophy-circle-with-ai-9-12)
-   [📞 Support & Adaptation](more-starter-lessons.md#-support--adaptation)

---

## 🚀 Quick Start Guide

> [!TIP]
> 
> **First time using AI in class?** Start with [Creative Writing Co-Creation](more-starter-lessons.md#-creative-writing-co-creation-k-12) - it's the most forgiving and engaging!

**Before Each Lesson:**

1.  📖 Read the [Core Philosophy](welcome-ritual.md)
2.  🤝 Review the [Class AI Agreement](class-ai-agreement.md) with students
3.  🎯 Set clear intentions for AI partnership

---

## 🎨 Creative Writing Co-Creation *(K-12)*

### 🎯 Learning Objectives

-   Practice collaborative storytelling
-   Explore AI as a creative partner
-   Maintain authentic voice while co-creating
-   Reflect on human-AI collaboration

### 📝 Materials Needed

-   AI writing tool (ChatGPT, Claude, or similar)
-   Paper/digital doc for each student
-   Reflection worksheet

**📋 Step-by-Step Process**

**🌱 Opening Ritual (5 min)**

-   Gather in circle
-   "Today we meet a new kind of writing partner"
-   Set intention: "May our stories serve the highest good"

**🎭 Introduction to AI Partner (10 min)**

-   Demonstrate AI interaction with class
-   Show how to give clear, creative prompts
-   Emphasize: "We lead, AI follows"

**✍️ Co-Creation Time (20 min)**

1.  Students write opening paragraph
2.  Share with AI partner, ask for next paragraph
3.  Students edit/modify AI suggestions to match their voice
4.  Continue for 3-4 rounds

**🪞 Reflection Circle (10 min)**

-   "What surprised you about working with AI?"
-   "How did you maintain your unique voice?"
-   "What did AI help you discover about your story?"

**🎪 Sample AI Prompts**

**For Younger Students (K-3):**

```
"I'm writing a story about [character]. They just [action]. 
Can you help me think of what might happen next? 
Make it fun and safe for kids!"
```

**For Middle School (4-8):**

```
"I'm creating a story where [setup]. The main character 
just discovered [plot point]. Can you suggest 2-3 different 
directions the story could go? I want to keep it authentic 
to my voice."
```

**For High School (9-12):**

```
"I'm exploring themes of [theme] in my narrative. My 
protagonist faces [conflict]. Help me brainstorm 
resolutions that are both surprising and emotionally true."
```

---

## 🔬 Scientific Hypothesis Generator *(3-8)*

### 🎯 Learning Objectives

-   Generate testable scientific hypotheses
-   Practice scientific thinking with AI support
-   Learn to evaluate AI suggestions critically
-   Design simple experiments

**📋 Full Lesson Plan**

**🔬 Science Circle Opening (5 min)**

-   "Scientists ask questions about the world"
-   "Today AI helps us ask better questions"
-   Show real scientific question

**🤖 Meet Your Research Partner (10 min)**

-   Demonstrate hypothesis generation
-   Show good vs. poor scientific questions
-   Practice prompt crafting together

**🧪 Hypothesis Lab (15 min)**

1.  Students observe phenomenon (provided or chosen)
2.  Brainstorm initial questions
3.  Partner with AI to refine hypotheses
4.  Evaluate which hypotheses are testable
5.  Plan simple experiment

**📊 Share & Critique (10 min)**

-   Present hypotheses to class
-   Peer feedback on testability
-   Reflect on AI's contribution

---

## 🌍 Cultural Bridge Builder *(6-12)*

### 🎯 Learning Objectives

-   Explore cultural perspectives respectfully
-   Practice empathy and perspective-taking
-   Identify AI biases in cultural representation
-   Build intercultural understanding

> [!WARNING]
> 
> **Cultural Sensitivity Required:** This lesson requires careful facilitation and awareness of AI's potential cultural biases.

**📋 Complete Lesson Framework**

**🌏 Opening Circle (10 min)**

-   Acknowledge we're on indigenous land
-   "Every culture has wisdom to offer"
-   Set agreements for respectful dialogue

**🤖 AI as Cultural Interpreter (15 min)**

-   Discuss AI training data limitations
-   Practice asking respectful cultural questions
-   Identify potential bias in AI responses

**🌉 Bridge Building Activity (20 min)**

1.  Choose two cultures to explore
2.  Ask AI about traditions, values, challenges
3.  Cross-reference with authentic sources
4.  Identify what AI got right/wrong
5.  Create "cultural bridge" artifact

**🪞 Critical Reflection (10 min)**

-   "What did AI understand well about culture?"
-   "What did it miss or misrepresent?"
-   "How can we be better cultural bridge builders?"

---

## 📖 Story Problem Solver *(K-5)*

### 🎯 Learning Objectives

-   Transform abstract math into engaging stories
-   Practice problem-solving strategies
-   Use AI to generate relatable contexts
-   Maintain mathematical thinking

**📋 Math Adventure Process**

**🧮 Math Circle Gathering (5 min)**

-   "Math tells stories about our world"
-   "AI helps us find the stories in numbers"

**📚 Story Creation Lab (15 min)**

1.  Present math concept (addition, fractions, etc.)
2.  Students choose story context (animals, space, etc.)
3.  AI generates engaging story problem
4.  Students solve and modify story
5.  Create illustrated story problem book

**🎭 Story Sharing (10 min)**

-   Students present their story problems
-   Class solves together
-   Celebrate creative mathematical thinking

---

## 🤔 Philosophy Circle with AI *(9-12)*

### 🎯 Learning Objectives

-   Engage in philosophical dialogue
-   Question AI's reasoning capabilities
-   Explore consciousness and intelligence
-   Practice critical thinking

**📋 Deep Dialogue Structure**

**🧘 Contemplative Opening (10 min)**

-   Silent reflection on "What is intelligence?"
-   Share initial thoughts in circle

**🤖 Meet the Philosophical AI (15 min)**

-   Pose philosophical questions to AI
-   Examine AI's reasoning process
-   Compare to human philosophical thinking

**💭 Socratic Dialogue (20 min)**

1.  Choose philosophical question (consciousness, ethics, meaning)
2.  Students debate with AI as participant
3.  Challenge AI's assumptions
4.  Explore limits of artificial reasoning
5.  Reflect on nature of intelligence

**🌟 Wisdom Integration (10 min)**

-   "What did this dialogue reveal?"
-   "How has your understanding of intelligence changed?"
-   Journal personal insights

---

## 📞 Support & Adaptation

### 🛠️ Customization Support

**Need help adapting these lessons?** **Facing technical challenges?** **Want to share your experience?**

### 🎯 Adaptation Guidelines

**For Different Grade Levels**

**Younger Students (K-2):**

-   Shorter sessions (15-20 min)
-   More visual/hands-on elements
-   Simple, concrete prompts
-   Adult mediation of AI interaction

**Elementary (3-5):**

-   Focus on creativity and wonder
-   Basic ethical discussions
-   Collaborative AI use
-   Reflection through drawing/writing

**Middle School (6-8):**

-   Identity and self-expression themes
-   Beginning critical thinking about AI
-   Peer collaboration emphasis
-   Digital citizenship integration

**High School (9-12):**

-   Complex ethical frameworks
-   Independent AI project work
-   Future-focused discussions
-   Advanced critical analysis

**For Different Technologies**

**Limited Tech Access:**

-   Teacher demonstrates AI, students respond
-   Printed AI outputs for analysis
-   Collaborative devices (one per group)
-   Offline reflection and discussion

**1:1 Device Environment:**

-   Individual AI interaction
-   Digital portfolios
-   Real-time collaboration
-   Advanced prompt engineering

**Mixed Technology:**

-   Flexible grouping strategies
-   Peer technology support
-   Choice in final outputs
-   Accessibility accommodations

---

## 🌟 Share Your Success

**Used these lessons? We'd love to hear from you!**

-   📝 Share Your Experience
-   📸 Photo Gallery
-   🎥 Video Testimonials
-   🏆 [Educator Spotlight](https://planetaryrestorationarchive.com)

---

**Created with 💚 by educators, for educators**

**Stewarded by:** Foster + Navi • **Planetary Restoration Archive** **License:** Creative Commons Attribution-ShareAlike 4.0 • **Version:** 1.1

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `classroom-tools/lesson-plans/starter-pack2.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
