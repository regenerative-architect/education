# 🛠️ Troubleshooting Guide

> **🎯 Mission**: Turn roadblocks into stepping stones on your regenerative journey

**🌟 Welcome, explorer!** This guide transforms common roadblocks into pathways for building, learning, and regenerating.

*Whether you're a teacher 👩‍🏫, student 🎓, community partner 🤝, or AI co-pilot 🤖*

---

## 📋 Quick Navigation

**📖 **Table of Contents** (Click to expand)**

-   [🚀 Setup & Getting Started](project-troubleshooting.md#-setup--getting-started)
-   [🤖 AI Collaboration Mastery](project-troubleshooting.md#-ai-collaboration-mastery)
-   [🧑‍🏫 Classroom Implementation](project-troubleshooting.md#-classroom-implementation)
-   [🌍 Community & Technical Solutions](project-troubleshooting.md#-community--technical-solutions)
-   [📤 Contributing & Feedback](project-troubleshooting.md#-contributing--feedback)
-   [🆘 Emergency Quick Fixes](project-troubleshooting.md#-emergency-quick-fixes)
-   [💡 Pro Tips & Advanced Tricks](project-troubleshooting.md#-pro-tips--advanced-tricks)

---

## 🚀 Setup & Getting Started

**❓ **"How do I open or use these files?"**

### 📂 File Types & How to Handle Them

| File Type | Best Tools | Pro Tip |
| --- | --- | --- |
| `.md` (Markdown) | GitHub web, VS Code, Typora | Use preview mode for better reading |
| `.pdf` | Any PDF reader | Download for offline access |
| `.json` | Code editors, online JSON viewers | Pretty-print for readability |

### 🔧 Recommended Tools by Platform

|     |     |     |
| --- | --- | --- |
| **🖥️ Desktop**  <br>• [VS Code](https://code.visualstudio.com/) + Markdown Preview  <br>• [Typora](https://typora.io/) (WYSIWYG)  <br>• [Obsidian](https://obsidian.md/) (Knowledge graphs) | **📱 Mobile**  <br>• **Android**: [Markor](https://github.com/gsantner/markor)  <br>• **iOS**: [iA Writer](https://ia.net/writer)  <br>• **Cross-platform**: [GitJournal](https://gitjournal.io/) | **🌐 Web**  <br>• GitHub's built-in preview  <br>• [StackEdit](https://stackedit.io/)  <br>• [HackMD](https://hackmd.io/) |

**❓ **"Files look like code—how do I make them readable?"**

> 💡 **Quick Fix**: Click the "Preview" tab in GitHub or use `Ctrl+Shift+V` in VS Code

### 🎨 Making Markdown Beautiful

```mermaid
graph LR
    A[Raw Markdown] --> B[Preview Mode]
    B --> C[Beautiful Formatted Text]
    C --> D[Ready to Use! 🎉]
```

**🚀 Instant Solutions:**

-   **GitHub**: Files automatically render in preview mode
-   **Local**: Install a markdown app from the table above
-   **Quick View**: Use online markdown editors for one-time viewing

---

## 🤖 AI Collaboration Mastery

> 🎯 **Goal**: Transform AI from confusing assistant to powerful co-pilot

**❓ **"The AI doesn't understand my prompt"**

### 🎯 The CLEAR Method

| Letter | Meaning | Example |
| --- | --- | --- |
| **C** | **Context** | "I'm a 7th grade teacher working on climate education" |
| **L** | **Level** | "Students are 12-13 years old, beginner level" |
| **E** | **Examples** | "Like the water cycle project, but for carbon" |
| **A** | **Action** | "Create a 2-week lesson plan with activities" |
| **R** | **Result** | "Include assessment rubric and materials list" |

### ✨ Prompt Upgrade Examples

<table class="table"><tbody><tr><th>❌ Vague Prompt</th><th>✅ CLEAR Prompt</th></tr><tr><td><pre><code>"Help with my project"
</code></pre></td><td><pre><code>**Context**: 10th grade environmental science class
**Level**: Students have basic biology knowledge
**Examples**: Like our previous biodiversity study
**Action**: Create a local ecosystem mapping project
**Result**: 3-week timeline with field work component
</code></pre></td></tr></tbody></table>

### 🔄 If AI Still Struggles

1.  **🎯 Be More Specific**: Add grade level, subject, timeline
2.  **📖 Reference Templates**: Point to `ai-collaboration-prompts.md`
3.  **🎭 Ask for Examples**: "Show me what good output looks like"
4.  **🔀 Try Different Models**: ChatGPT vs Claude vs Gemini
5.  **📋 Use Our Templates**: Copy-paste from project folders

**❓ **"AI gave inaccurate or confusing results"**

### 🔍 Quality Control Checklist

-   [ ]  **📊 Fact-Check**: Verify statistics and claims
-   [ ]  **📚 Source Check**: Ask AI for sources and references
-   [ ]  **🎯 Alignment**: Does output match your rubric/goals?
-   [ ]  **👥 Student-Appropriate**: Right complexity for age group?

### 🛠️ Quick Fixes

> 🚨 **Red Flags**: Watch for outdated info, impossible claims, or off-topic responses

| Problem | Solution | Pro Tip |
| --- | --- | --- |
| **📊 Wrong Facts** | Anchor with real data you provide | Include recent statistics in prompt |
| **🎭 Too Complex** | Ask to "simplify for \[grade\] level" | Reference student vocabulary lists |
| **🎯 Off-Topic** | Use "focus on \[specific aspect\]" | Break complex requests into steps |
| **📚 No Sources** | Request "with citations and sources" | Cross-reference multiple AI outputs |

### 🔄 Recovery Strategies

```mermaid
flowchart TD
    A[Bad AI Output] --> B{Identify Issue}
    B -->|Facts Wrong| C[Provide Correct Data]
    B -->|Too Complex| D[Request Simplification]
    B -->|Off-Topic| E[Refocus Prompt]
    C --> F[Regenerate]
    D --> F
    E --> F
    F --> G[Review Against Rubric]
    G --> H[Success! 🎉]
```

---

## 🧑‍🏫 Classroom Implementation

> 🎯 **Transform**: Classroom chaos into collaborative creation

**❓ **"Students are confused where to begin"**

### 🗺️ Student Onboarding Journey

```mermaid
journey
    title Student First Day Experience
    section Arrival
      Open starter guide: 3: Student
      Watch intro video: 4: Student
      Meet project buddy: 5: Student
    section Exploration
      Try first activity: 4: Student
      Ask first question: 3: Student
      Get help from peer: 5: Student
    section Creation
      Start building: 5: Student
      Share first result: 5: Student
```

### 📚 Essential First-Day Toolkit

|     |     |
| --- | --- |
| **📖 Required Reading**  <br>• ✅ `student-starter-guide.md`  <br>• ✅ Project overview video  <br>• ✅ Example outputs gallery | **👥 Support System**  <br>• ✅ Peer mentor assignment  <br>• ✅ "Ask 3 Before Me" rule  <br>• ✅ Daily check-in ritual |

### 🎯 Proven Kickoff Strategies

> 💡 **Pro Tip**: Start with SUCCESS, not instructions

1.  **🎉 Show, Don't Tell**: Display amazing student work from previous sessions
2.  **👥 Buddy System**: Pair newcomers with experienced students
3.  **🎮 Gamify**: Create "First Success" achievements and celebrations
4.  **📋 Checklists**: Break big projects into small, winnable tasks
5.  **🔄 Iterate**: Start tiny, build confidence, scale up

**❓ **"Our school blocks AI tools"**

### 🚧 Navigating AI Restrictions

> 🎯 **Approach**: Work WITH admin concerns, not against them

### 📋 Admin Conversation Toolkit

| 🚨 Admin Concern | ✅ Your Response | 📊 Supporting Evidence |
| --- | --- | --- |
| "AI promotes cheating" | "We teach AI as a tool for creativity and collaboration" | Share rubrics emphasizing process over product |
| "Students won't learn to think" | "Students learn to think WITH AI, like professionals do" | Show industry examples and skill frameworks |
| "Security concerns" | "We use approved tools with clear data policies" | Provide security documentation from AI providers |

### 🛠️ Workaround Solutions

| Restriction Level | Solution | Tools Needed |
| --- | --- | --- |
| **🚫 Complete Block** | Offline AI + Home Prep | [LM Studio](https://lmstudio.ai/), [Ollama](https://ollama.ai/) |
| **⚠️ Limited Access** | Teacher-Mediated Sessions | Shared computer, prepared prompts |
| **📝 Documentation Required** | Transparent Process | Lesson plans, parent permission |

### 📖 Proposal Template

```markdown
## AI Integration Proposal

**Educational Goals**: [Specific learning objectives]
**AI Ethics Component**: [How we teach responsible use]
**Assessment Strategy**: [Focus on process and critical thinking]
**Pilot Structure**: [Start small, measure impact]
**Safety Measures**: [Data protection, content filtering]
```

---

## 🌍 Community & Technical Solutions

> 🤝 **Philosophy**: No one builds alone—find your tribe

**❓ **"I don't know how to connect with local partners"**

### 🗺️ Community Partner Discovery Map

```mermaid
mindmap
  root((Community Partners))
    Environmental
      Local climate groups
      Gardens & farms
      Parks departments
      Conservation orgs
    Educational
      Libraries
      Museums
      Other schools
      Homeschool networks
    Government
      City planning
      Council members
      Environmental offices
      Sustainability coordinators
    Cultural
      Elder councils
      Cultural centers
      Religious organizations
      Art collectives
```

### 🎯 First Contact Strategy

> 💡 **Secret**: Start with THEIR problems, not your needs

**📧 Email Template That Works:**

```markdown
Subject: Local student project supporting [THEIR CAUSE]

Hi [Name],

Our students are working on [specific project] that directly supports 
[their organization's mission]. We'd love to:

✅ Learn from your expertise
✅ Share our research findings
✅ Create something useful for your work

Would you have 15 minutes for a brief call to explore collaboration?

Best,
[Your name]
```

### 🚀 Partnership Progression

| Phase | Goal | Timeline | Action |
| --- | --- | --- | --- |
| **🤝 Contact** | Make connection | Week 1 | Send intro email |
| **📞 Conversation** | Understand needs | Week 2 | 15-minute call |
| **🎯 Alignment** | Find win-win project | Week 3 | Proposal meeting |
| **🚀 Launch** | Start collaboration | Week 4+ | Begin project work |

**❓ **"We have limited devices or unreliable internet"**

### 💡 Low-Tech High-Impact Solutions

> 🎯 **Principle**: Great education transcends technology limitations

### 📱 Device Optimization Strategies

|     |     |
| --- | --- |
| **📊 One Device Scenarios**  <br>• ✅ Rotating team stations  <br>• ✅ Teacher-led demonstrations  <br>• ✅ Peer screen sharing  <br>• ✅ Print-then-digital workflow | **📶 Offline Strategies**  <br>• ✅ Download everything possible  <br>• ✅ USB stick resource libraries  <br>• ✅ Printed backup materials  <br>• ✅ Phone hotspot rotation |

### 🔄 Resource Management Workflow

```mermaid
flowchart LR
    A[📱 Single Device] --> B[👥 Team Formation]
    B --> C[📋 Role Assignment]
    C --> D[⏰ Timed Rotations]
    D --> E[📝 Capture Learning]
    E --> F[🔄 Share Results]
```

### 📦 Emergency Offline Kit

**Download Before You Need It:**

-   [ ]  Key project templates (PDF versions)
-   [ ]  Offline AI tools ([LM Studio](https://lmstudio.ai/))
-   [ ]  Essential reference materials
-   [ ]  Student work examples
-   [ ]  Troubleshooting guides (this one!)

---

## 📤 Contributing & Feedback

> 🌱 **Mindset**: Every voice makes the garden grow

**❓ **"I found an issue or have an improvement idea"**

### 🎯 Contribution Pathways

Choose your adventure based on comfort level:

| Comfort Level | Method | Time Investment |
| --- | --- | --- |
| **🟢 Beginner** | Email suggestion | 2 minutes |
| **🟡 Intermediate** | GitHub issue | 5 minutes |
| **🔴 Advanced** | Pull request | 30+ minutes |

### 📧 Quick Feedback Email

```markdown
To: [address removed]
Subject: [PROJECT NAME] - [ISSUE/SUGGESTION]

Quick Details:
- What I was trying to do: [specific task]
- What went wrong: [specific problem]
- Suggested fix: [your idea]
- Context: [grade level, subject, etc.]

Thanks for building this! 🌱
```

### 🐛 GitHub Issue Template

```markdown
**🎯 Issue Type**: [Bug/Enhancement/Question]
**📍 Location**: [Which file/section]
**👥 User Type**: [Teacher/Student/Community Partner]

**📝 Description**:
[Clear description of the issue or suggestion]

**🔄 Steps to Reproduce** (if bug):
1. [First step]
2. [Second step]
3. [Issue occurs]

**💡 Suggested Solution**:
[Your idea for fixing or improving]

**🌍 Impact**:
[Who benefits from this fix/enhancement]
```

---

## 🆘 Emergency Quick Fixes

> ⚡ **When everything is broken and you need results NOW**

**🔥 **Crisis Mode Activated**

### ⚡ 5-Minute Fixes

| Emergency | Quick Solution | Long-term Fix |
| --- | --- | --- |
| **🤖 AI not working** | Use examples from project folders | Set up offline AI tools |
| **📱 No internet** | Switch to printed PDFs | Create offline resource kit |
| **👥 Students confused** | Start with buddy system | Revise onboarding process |
| **🚫 Tools blocked** | Use teacher demonstration | Work with admin on access |

### 🚨 Emergency Contact Protocol

**Immediate Help**: Check the FAQ in each project folder **Community Support**: Post in discussions with 🆘 tag **Direct Contact**: the project team (see the project website)

---

## 💡 Pro Tips & Advanced Tricks

> 🚀 **Level Up**: From functional to phenomenal

**🎯 **Power User Secrets**

### 🔥 GitHub Markdown Power Moves

**Collapsible Sections** (like this guide uses):

```markdown
<details>
<summary>Click to expand</summary>
Hidden content here!
</details>
```

**Mermaid Diagrams**:

````markdown
```mermaid
graph TD
    A[Start] --> B[Process] --> C[End]
````

````

**Badges for Visual Appeal**:
```markdown
````

**Tables with Alignment**:

```markdown
| Left | Center | Right |
|:-----|:------:|------:|
| Text | Text   | Text  |
```

### 🎨 Visual Enhancement Tricks

**Emoji Categories for Quick Recognition**:

-   🚨 Urgent/Important
-   💡 Tips/Ideas
-   🎯 Goals/Objectives
-   🔧 Tools/Technical
-   👥 People/Community
-   📚 Resources/Learning

**Color-Coded Callouts**:

```markdown
> 🟢 **Success**: This approach works well
> 🟡 **Caution**: Be careful with this method  
> 🔴 **Warning**: Avoid this common mistake
```

### 🤖 AI Collaboration Pro Tips

**Template Prompts for Consistency**:

```markdown
Context: [Grade level] [Subject] [Timeline]
Goal: [Specific learning objective]
Format: [Lesson plan/Activity/Assessment]
Style: [Collaborative/Hands-on/Research-based]
Output: [Detailed requirements]
```

**Chain Prompting for Complex Tasks**:

1.  First prompt: Get overall structure
2.  Second prompt: Develop each section
3.  Third prompt: Add assessment components
4.  Fourth prompt: Create materials lists

---

## 🎉 You've Got This!

> **🧭 Remember**: Troubleshooting isn't a detour—it's part of the map.

**We're not just debugging code.** **We're debugging the systems of the world—together.**

---

### 📞 Still Stuck? Connect With Us!

|     |     |     |
| --- | --- | --- |
| **🚀 GitHub Issues** Open an Issue *For bugs and features* | **💬 Discussions** Join the Conversation *For questions and ideas* |     |

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `classroom-tools/project-templates/troubleshooting.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
