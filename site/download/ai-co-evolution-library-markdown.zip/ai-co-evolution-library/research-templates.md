# 🌿 Local Ecosystem Study Research Templates

## 📋 Template Overview

These templates provide structured frameworks for conducting comprehensive ecosystem research with AI collaboration. Each template includes spaces for both independent observations and AI-assisted analysis.

**Template Collection:**

-   🎯 Research Planning Template
-   📊 Field Data Collection Templates
-   🤖 AI Collaboration Log
-   📈 Data Analysis Worksheet
-   📝 Scientific Report Template
-   🌍 Community Presentation Template

---

## 🎯 Research Planning Template

### Project Information

**Student Name(s):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Grade Level:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Project Timeline:** Start Date: \_\_\_\_\_\_\_ End Date: \_\_\_\_\_\_\_ **Study Site Location:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Ecosystem Type:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### 1\. Research Question Development

#### Initial Observations

*Spend time observing your ecosystem before developing research questions*

**What I Notice (Use all your senses):**

-   **Visual observations:**
-   **Sounds:**
-   **Smells:**
-   **Textures:**
-   **Weather/climate patterns:**
-   **Human impacts:**
-   **Interesting patterns or relationships:**

#### AI Brainstorming Session

**AI Prompt Used:**

```
[Copy your prompt here]
```

**AI Suggested Research Areas:** 1. 2. 3. 4. 5.

**My Evaluation of AI Suggestions:**

-   Most interesting to me:
-   Most feasible with my resources:
-   Most important for ecosystem health:

#### Final Research Question

**Primary Research Question:**

---

**Why this question matters:**

-   **To me personally:**
-   **To the ecosystem:**
-   **To the broader community:**

**Testable predictions (hypotheses):** 1. 2. 3.

### 2\. Background Research Planning

#### Key Concepts to Research

*What do I need to understand before starting data collection?*

## **Ecosystem-specific concepts:**

## **Species identification needs:**

## **Environmental factors to understand:**

#### AI Research Strategy

**AI Role-Playing Prompts to Use:**

-   [ ]  "Act as an ecologist specializing in \[ecosystem type\]..."
-   [ ]  "Act as a field guide expert for \[region\]..."
-   [ ]  "Act as an environmental educator..."
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Information Sources to Verify AI Responses:**

-   [ ]  Field guides
-   [ ]  Scientific websites (.edu, .gov, .org)
-   [ ]  Local environmental organizations
-   [ ]  Teacher/expert consultation
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### 3\. Methodology Planning

#### What Will I Measure/Observe?

**Biological factors:**

-   Species diversity/abundance
-   Behavior observations
-   Plant growth patterns
-   Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Physical/Chemical factors:**

-   Temperature
-   pH (if applicable)
-   Light levels
-   Soil characteristics
-   Water quality (if applicable)
-   Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Human impact indicators:**

-   Pollution signs
-   Habitat disturbance
-   Infrastructure effects
-   Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Sampling Strategy

**Number of study sites:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Frequency of observations:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Duration of each observation session:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Best times to collect data:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Weather considerations:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Equipment Needed

**Available to me:**

-   [ ]  Camera/phone for photos
-   [ ]  Measuring tools (ruler, tape measure)
-   [ ]  Thermometer
-   [ ]  pH strips/meter
-   [ ]  Collection containers
-   [ ]  Field notebook
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Would like to borrow/acquire:**

-   [ ]  Binoculars
-   [ ]  Magnifying glass
-   [ ]  Light meter
-   [ ]  Scale
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### 4\. Potential Challenges & Solutions

#### Anticipated Challenges

**Environmental challenges:**

-   Weather-related issues:
-   Seasonal timing:
-   Site access:

**Technical challenges:**

-   Equipment limitations:
-   Identification difficulties:
-   Measurement accuracy:

**AI-related challenges:**

-   Information verification:
-   Over-reliance prevention:
-   Technical difficulties:

#### Contingency Plans

**If weather is bad:** **If equipment fails:** **If AI gives conflicting information:** **If I can't identify species:**

### 5\. Success Criteria

**How will I know my research was successful?**

-   [ ]  I can answer my research question with confidence
-   [ ]  I collected sufficient, reliable data
-   [ ]  I can explain my findings to others
-   [ ]  I learned something new about ecosystems
-   [ ]  I can suggest actions to help the ecosystem
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

## 📊 Field Data Collection Templates

### Template A: Biodiversity Survey

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Time:** \_\_\_\_\_\_\_\_\_ **Weather:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Site:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Observer:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Survey Area Size:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Survey Duration:** \_\_\_\_\_\_\_\_\_\_\_\_\_

#### Species Observed

| Species Name | Common Name | Count/Abundance | Location in Site | Behavior Notes | Photo Y/N |
| --- | --- | --- | --- | --- | --- |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |

#### Species Identification Notes

**Species needing further identification:**

1.  **Description:** **AI identification assistance:** **Confidence level:** **Additional verification needed:**
    
2.  **Description:** **AI identification assistance:** **Confidence level:** **Additional verification needed:**
    

#### Environmental Conditions

**Temperature:** \_\_\_\_\_ °F/°C **Light conditions:** \[ \] Full sun \[ \] Partial shade \[ \] Deep shade **Wind:** \[ \] None \[ \] Light breeze \[ \] Moderate \[ \] Strong **Recent weather:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Human disturbance level:** \[ \] None \[ \] Low \[ \] Moderate \[ \] High

#### Overall Observations

**Dominant species:** **Interesting interactions observed:** **Signs of ecosystem health:** **Signs of ecosystem stress:** **Questions raised for future investigation:**

---

### Template B: Habitat Assessment

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Site:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Observer:** \_\_\_\_\_\_\_\_\_\_\_\_\_

#### Physical Characteristics

**Habitat type:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Size of study area:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Elevation:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Slope/topography:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Aspect (direction facing):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Vegetation Structure

**Canopy cover:** \_\_\_\_\_ % (estimate) **Understory density:** \[ \] Dense \[ \] Moderate \[ \] Sparse \[ \] None **Ground cover type:** \[ \] Grass \[ \] Leaf litter \[ \] Bare soil \[ \] Rock \[ \] Other: \_\_\_\_\_

**Dominant plant species:** 1. 2. 3.

#### Substrate/Soil

**Soil type:** \[ \] Clay \[ \] Sand \[ \] Loam \[ \] Rocky \[ \] Other: \_\_\_\_\_ **Soil moisture:** \[ \] Dry \[ \] Moist \[ \] Wet \[ \] Saturated **Soil color:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **pH (if measured):** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Organic matter present:** \[ \] High \[ \] Moderate \[ \] Low

#### Water Features

**Water present:** \[ \] Yes \[ \] No **If yes, type:** \[ \] Stream \[ \] Pond \[ \] Wetland \[ \] Seasonal \[ \] Other: \_\_\_\_\_ **Water quality indicators:**

-   Clarity: \[ \] Clear \[ \] Slightly cloudy \[ \] Murky
-   Odor: \[ \] None \[ \] Natural \[ \] Chemical \[ \] Unpleasant
-   Visible pollution: \[ \] None \[ \] Litter \[ \] Chemical \[ \] Other: \_\_\_\_\_

#### Human Impact Assessment

**Infrastructure nearby:**

-   [ ]  Roads (distance: \_\_\_\_\_)
-   [ ]  Buildings (distance: \_\_\_\_\_)
-   [ ]  Power lines
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Visible human impacts:**

-   [ ]  Litter/trash
-   [ ]  Erosion from foot traffic
-   [ ]  Invasive species
-   [ ]  Chemical pollution signs
-   [ ]  Habitat fragmentation
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Management evidence:**

-   [ ]  Trail maintenance
-   [ ]  Restoration work
-   [ ]  Conservation signage
-   [ ]  Invasive species control
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

### Template C: Temporal Change Documentation

**Study Period:** From \_\_\_\_\_\_\_ to \_\_\_\_\_\_\_ **Observation Frequency:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Tracking Changes Over Time

| Date | Weather | Key Observations | Species Changes | Environmental Changes | Photos Taken |
| --- | --- | --- | --- | --- | --- |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |
|     |     |     |     |     |     |

#### Seasonal Patterns Noticed

**Early observations (Week 1-2):**

**Mid-study observations (Week 3-4):**

**Late observations (Week 5-6+):**

#### Questions for AI Analysis

**Patterns I've noticed:**

**AI prompt for pattern analysis:**

```
[Your prompt here]
```

**AI insights about temporal patterns:**

**My evaluation of AI insights:**

---

## 🤖 AI Collaboration Log

### AI Interaction Record

#### Session 1: Research Question Development

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **AI Platform Used:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Purpose:** Research question brainstorming

**My Initial Prompt:**

```
[Copy exact prompt here]
```

**AI Response Summary:**

**What was helpful:**

**What I questioned or disagreed with:**

**Follow-up prompts used:** 1. 2. 3.

**How this influenced my research design:**

**Verification steps taken:**

---

#### Session 2: Species Identification

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Species in question:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Description I provided to AI:**

**AI identification suggestions:**

1.  **Species:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence:** \_\_\_\_\_
2.  **Species:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence:** \_\_\_\_\_
3.  **Species:** \_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence:** \_\_\_\_\_

**Additional identification resources I consulted:**

-   [ ]  Field guide: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  iNaturalist community ID
-   [ ]  Expert consultation: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   [ ]  Additional photos/observations
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Final identification:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Confidence level:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

#### Session 3: Data Analysis Support

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Data shared with AI:** \[Brief description\]

**AI analysis prompt:**

```
[Copy prompt here]
```

**AI identified patterns:**

**AI suggested explanations:**

**My agreement/disagreement with AI analysis:**

**Additional analysis I conducted independently:**

---

#### Session 4: Research Interpretation

**Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Purpose:** Understanding broader implications

**My findings summary shared with AI:**

**AI connections to ecological principles:**

**AI suggestions for broader implications:**

**Literature/sources AI recommended:**

**Which suggestions I verified and how:**

---

### AI Collaboration Reflection

#### What I Learned About Working with AI

**Most valuable AI assistance:**

**Times AI was wrong or unhelpful:**

**How I improved my AI interaction skills:**

**Strategies I developed for verifying AI information:**

#### Balance of AI vs. Personal Work

**Tasks where AI was most helpful:**

-   [ ]  Background research
-   [ ]  Species identification
-   [ ]  Data pattern recognition
-   [ ]  Connecting to broader concepts
-   [ ]  Generating research questions
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Tasks where my human skills were essential:**

-   [ ]  Field observations
-   [ ]  Data collection
-   [ ]  Critical thinking about results
-   [ ]  Understanding local context
-   [ ]  Making value judgments
-   [ ]  Creative problem-solving
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**How AI enhanced rather than replaced my learning:**

---

## 📈 Data Analysis Worksheet

### Data Summary

#### Quantitative Data Overview

**Total observation sessions:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Total species observed:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Most abundant species:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Rarest species observed:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Measurements collected:**

| Variable | Units | Range | Average | Notes |
| --- | --- | --- | --- | --- |
|     |     |     |     |     |
|     |     |     |     |     |
|     |     |     |     |     |

#### Patterns I Noticed Independently

**Before consulting AI:** 1. 2. 3.

#### AI-Assisted Pattern Analysis

**Data shared with AI for analysis:** \[Brief description of what data you provided\]

**AI prompt used:**

```
[Copy your analysis prompt here]
```

**Patterns AI identified:** 1. 2. 3.

**AI explanations for patterns:**

#### Pattern Verification

## **Patterns confirmed by multiple sources:**

## **Patterns requiring more investigation:**

## **Patterns I disagreed with AI about:**

### Statistical Analysis (if applicable)

#### Basic Calculations

**Species diversity calculation:**

-   Number of species: \_\_\_\_\_
-   Shannon diversity index (if calculated): \_\_\_\_\_
-   Simpson's index (if calculated): \_\_\_\_\_

**Correlation analysis:**

-   Variables compared: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Relationship observed: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
-   Strength of relationship: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Visual Data Representation

**Graphs/charts created:**

-   [ ]  Species abundance chart
-   [ ]  Environmental variable graphs
-   [ ]  Time series plots
-   [ ]  Comparison charts
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Most effective visualization for my data:**

**How visualizations revealed new insights:**

### Interpretation & Conclusions

#### Answering My Research Question

**My original research question:**

**Answer based on my data:**

**Confidence level in my answer:** \[ \] High \[ \] Medium \[ \] Low **Why this confidence level:**

#### Connections to Ecological Principles

**Ecological concepts my research demonstrates:** 1. 2. 3.

**How my local findings connect to broader environmental patterns:**

#### Limitations & Future Research

**Limitations of my study:** 1. 2. 3.

**Questions raised for future investigation:** 1. 2. 3.

**How I would improve this study if I did it again:**

---

## 📝 Scientific Report Template

### Title Page

**Title:** \[Descriptive title that captures your main finding\] **Student Name:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **School:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Date:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Grade Level:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### Abstract (150-250 words)

*Write this section last - it's a summary of your entire project*

**Research Question:** \[One sentence\] **Methods:** \[2-3 sentences about what you did\] **Key Findings:** \[2-3 sentences about main results\] **Significance:** \[1-2 sentences about why this matters\]

### Introduction

#### Study Site Description

**Location and Setting:**

**Ecosystem Type and Characteristics:**

**Why I Chose This Site:**

#### Background Research

**Key Ecological Concepts Relevant to My Study:** \[Explain the science behind your research question\]

**Previous Research in Similar Ecosystems:** \[What have other scientists found? Include AI-assisted literature review but verify key claims\]

**AI Collaboration in Background Research:** *Briefly describe how AI helped with background research and how you verified information*

#### Research Question and Hypotheses

**Primary Research Question:**

**Specific Hypotheses:** 1. 2. 3.

**Predictions Based on Ecological Theory:**

### Methods

#### Study Design

**Research Approach:** \[Observational study, comparative study, etc.\] **Sampling Strategy:** \[How you chose what to measure and when\] **Study Duration:** \[Time period and frequency of observations\]

#### Data Collection Procedures

**Field Methods:** \[Step-by-step description of what you did in the field\]

**Equipment Used:**

**AI Assistance in Methodology:** *Describe how AI helped refine your methods and how you validated methodological choices*

#### Data Recording and Management

**Data Organization System:**

**Quality Control Measures:**

### Results

#### Data Summary

**Overview of Data Collected:** \[Quantitative summary of your observations\]

**Species Inventory:** \[List of species observed with abundance information\]

#### Key Findings

**Major Patterns Identified:** 1. 2. 3.

**Statistical Analysis Results:** \[If applicable - basic calculations, averages, correlations\]

**Visual Data Presentation:** \[Reference your graphs, charts, photos with brief descriptions\]

**AI Assistance in Analysis:** *Describe how AI helped identify patterns and how you verified these insights*

#### Unexpected Observations

**Surprising Findings:**

**Observations That Contradicted Expectations:**

### Discussion

#### Interpretation of Results

**What My Findings Mean:** \[Explain the ecological significance of your results\]

**Connection to Ecological Principles:** \[How your results illustrate broader ecological concepts\]

**Comparison to Previous Research:** \[How your findings compare to what other scientists have found\]

#### Evaluation of Hypotheses

**Hypothesis 1:** \[Supported/Not supported - explain why\]

**Hypothesis 2:** \[Supported/Not supported - explain why\]

**Hypothesis 3:** \[Supported/Not supported - explain why\]

#### Broader Implications

**What My Research Suggests About:**

-   Ecosystem health:
-   Environmental management:
-   Conservation needs:
-   Climate change impacts:

**AI Insights on Broader Implications:** *How AI helped connect local findings to global patterns, with verification notes*

#### Study Limitations

**Factors That May Have Affected My Results:** 1. 2. 3.

**How These Limitations Affect My Conclusions:**

### Conclusions

#### Summary of Key Findings

**Most Important Discovery:**

**Answer to Research Question:**

**Ecological Significance:**

#### Recommendations

**For Ecosystem Management:**

**For Future Research:**

**For Community Action:**

### AI Collaboration Reflection

*Separate section documenting AI use throughout the project*

#### AI Tools and Platforms Used

**Primary AI Platform:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ **Specific AI Assistance Provided:**

-   [ ]  Research question development
-   [ ]  Literature review support
-   [ ]  Species identification
-   [ ]  Data analysis
-   [ ]  Pattern interpretation
-   [ ]  Writing assistance
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Evaluation of AI Collaboration

**Most Valuable AI Contributions:**

**Times AI Was Incorrect or Unhelpful:**

**How I Verified AI Information:**

**Balance of AI Assistance vs. Personal Work:**

**Skills I Developed in AI Collaboration:**

### References

*Include all sources used, including AI platforms*

**Scientific Sources:** 1. 2. 3.

**AI Platforms:**

-   \[AI Platform Name\]. (Date of interaction). \[Brief description of assistance provided\].

**Field Guides and Other Resources:** 1. 2. 3.

### Appendices

**Appendix A:** Raw data tables **Appendix B:** Additional photographs **Appendix C:** AI interaction transcripts (selected examples) **Appendix D:** Species identification verification

---

## 🌍 Community Presentation Template

### Presentation Planning Worksheet

#### Audience Analysis

**Who will be in my audience?**

-   [ ]  Fellow students
-   [ ]  Teachers and parents
-   [ ]  Community members
-   [ ]  Local government officials
-   [ ]  Environmental organizations
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**What does my audience already know about ecosystems?**

-   [ ]  Expert level
-   [ ]  Some background knowledge
-   [ ]  Basic understanding
-   [ ]  Little to no background

**What does my audience care about most?**

-   [ ]  Scientific accuracy
-   [ ]  Environmental protection
-   [ ]  Economic impacts
-   [ ]  Community health
-   [ ]  Educational value
-   [ ]  Other: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### Key Messages

**My main findings (3 key points maximum):** 1. 2. 3.

**Why these findings matter to my audience:** 1. 2. 3.

**Actions I want my audience to take:** 1. 2. 3.

#### AI Assistance for Presentation

**AI prompt for audience adaptation:**

```
I need to present my ecosystem research findings about [brief summary] to [audience description]. Help me adapt my scientific findings for this audience by suggesting: 1) What aspects would be most important to them, 2) How to translate technical terms, 3) What questions they might ask.
```

**AI suggestions for audience adaptation:**

**AI recommendations I'm using:**

**AI recommendations I'm modifying or rejecting:**

### Presentation Outline

#### Opening (2-3 minutes)

**Hook:** \[Interesting observation, surprising fact, or compelling photo\]

**Why this matters:** \[Connect immediately to audience interests\]

**What I'll cover:** \[Brief preview of main points\]

#### Main Content (8-12 minutes)

**Section 1: What I Studied**

-   Study site description (use photos!)
-   Research question in plain language
-   Why I chose this focus

**Section 2: What I Discovered**

-   Key finding 1: \[with visual evidence\]
-   Key finding 2: \[with visual evidence\]
-   Key finding 3: \[with visual evidence\]
-   Most surprising discovery

**Section 3: What It Means**

-   Connection to bigger environmental issues
-   Implications for our community
-   What needs protection or improvement

#### Call to Action (1-2 minutes)

**Specific actions for my audience:** 1. 2. 3.

**How to get involved or learn more:**

#### Q&A Preparation

**Questions I expect:**

1.  Q: A:
    
2.  Q: A:
    
3.  Q: A:
    

**AI-assisted Q&A preparation:** *How AI helped me anticipate questions and prepare answers*

### Visual Aids Planning

#### Essential Visuals

**Must-include photos:**

-   [ ]  Study site overview
-   [ ]  Key species observed
-   [ ]  Evidence of main findings
-   [ ]  Before/after or comparison shots
-   [ ]  Community connection images

**Data visualizations needed:**

-   [ ]  Species abundance chart
-   [ ]  Environmental data graphs
-   [ ]  Comparison charts
-   [ ]  Maps or site diagrams
-   [ ]  Infographic summary

#### AI Assistance with Visuals

**AI suggestions for visual design:**

**AI help with data visualization:**

### Technical Requirements

#### Equipment Needed

-   [ ]  Computer/laptop
-   [ ]  Projector/display screen
-   [ ]  Microphone (if needed)
-   [ ]  Extension cord
-   [ ]  USB drive backup
-   [ ]  Handouts (if desired)

#### Backup Plans

**If technology fails:**

**If time is shortened:**

**If audience is different than expected:**

### Post-Presentation Follow-Up

#### Information Sharing

**Resources to provide:**

-   [ ]  Digital copy of presentation
-   [ ]  Contact information for questions
-   [ ]  Links to relevant websites
-   [ ]  Action step resources
-   [ ]  Additional reading suggestions

#### Success Evaluation

**How I'll know my presentation was successful:**

-   [ ]  Audience engagement during presentation
-   [ ]  Quality of questions asked
-   [ ]  Follow-up interest or actions
-   [ ]  Personal learning and growth
-   [ ]  Positive feedback received

#### AI Collaboration Documentation

**How AI enhanced my presentation:**

**What I contributed that AI couldn't:**

**Overall evaluation of AI-human collaboration:**

---

## 📋 Template Usage Guidelines

### Getting Started

1.  **Choose appropriate templates** based on your research focus and timeline
2.  **Customize templates** to match your specific ecosystem and research question
3.  **Use templates as guides** - don't feel constrained by every section
4.  **Document your process** as you work through each template

### AI Integration Tips

-   **Use AI to enhance, not replace** your thinking in each template section
-   **Always verify AI suggestions** before incorporating them into your work
-   **Document AI interactions** clearly in the collaboration log
-   **Balance AI assistance** with your own observations and critical thinking

### Quality Assurance

-   **Review completed templates** for completeness and accuracy
-   **Cross-check information** between different templates for consistency
-   **Verify all AI-assisted content** through additional sources
-   **Get feedback** from teachers or peers on template use

### Customization Notes

-   **Modify sections** that don't apply to your specific study
-   **Add sections** for unique aspects of your research
-   **Adjust complexity** based on your grade level and project scope
-   **Scale templates** for individual or group projects

---

**Remember: These templates are tools to support your learning and research. The most important element is your own curiosity, observation skills, and critical thinking about the natural world around you!** 🌱🔬

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `classroom-tools/project-templates/systems-thinking-projects/local-ecosystem-study/resources/research-templates.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
