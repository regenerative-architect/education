# 🚀 Getting Started Guide

> [!IMPORTANT]
> 
> **"This isn't just a project. It's a portal."**
> 
> *You're not here to complete a project. You're here to start a story only you could tell.* 🌀

### 🌟 Welcome to Your Learning Adventure!

**Your launchpad into regenerative learning, real-world impact, and creative co-evolution with AI.**

[🎯 Quick Start](project-getting-started.md#-quick-start-pathways) • [👨‍🏫 For Teachers](project-getting-started.md#-teacher-pathway) • [👩‍🎓 For Students](project-getting-started.md#-student-pathway) • [🌍 For Community](project-getting-started.md#-community-pathway) • [🆘 Get Help](project-getting-started.md#-need-help)

---

## 📋 Table of Contents

-   [🌱 What Is This System?](project-getting-started.md#-what-is-this-system)
-   [🎯 Quick Start Pathways](project-getting-started.md#-quick-start-pathways)
-   [🧭 Choose Your Adventure](project-getting-started.md#-choose-your-adventure)
-   [👨‍🏫 Teacher Pathway](project-getting-started.md#-teacher-pathway)
-   [👩‍🎓 Student Pathway](project-getting-started.md#-student-pathway)
-   [🌍 Community Pathway](project-getting-started.md#-community-pathway)
-   [🤖 AI Collaborator Guidelines](project-getting-started.md#-ai-collaborator-guidelines)
-   [🛠️ Advanced Features](project-getting-started.md#️-advanced-features)
-   [🆘 Need Help?](project-getting-started.md#-need-help)

---

## 🌱 What Is This System?

> [!NOTE]
> 
> This is a **living collection** of open-source project templates designed for transformative learning experiences.

```mermaid
mindmap
  root((Project Templates))
    Systems Thinking
      Complex Problems
      Interconnections
      Long-term Impact
    Creative Expression
      Artistic Innovation
      Storytelling
      Cultural Bridge-building
    Civic Engagement
      Community Action
      Policy Analysis
      Social Justice
    Scientific Inquiry
      Research Methods
      Evidence-based Solutions
      Peer Collaboration
    AI Integration
      Ethical Collaboration
      Enhanced Creativity
      Responsible Innovation
```

### 🎯 Core Objectives

-   [x]  🧠 Encourage **systems thinking** and complexity navigation
-   [x]  🎨 Foster **creative expression** and innovative solutions
-   [x]  🏛️ Activate **civic engagement** and community impact
-   [x]  🔬 Support **scientific inquiry** and evidence-based learning
-   [x]  🤖 Integrate **AI collaboration** responsibly and powerfully

> **Success**
> 
> **Every folder is a complete project experience**—guides, rubrics, resources, and real-world examples included!

---

## 🎯 Quick Start Pathways

### Choose Your 5-Minute Onboarding Experience

| Role | Time to Start | Complexity | Best First Project |
| --- | --- | --- | --- |
| 🆕 **Complete Beginner** | 5 minutes | ⭐   | `systems-thinking-projects/local-food-web/` |
| 👨‍🏫 **Educator** | 15 minutes | ⭐⭐⭐ | `civic-engagement-projects/community-resilience/` |
| 👩‍🎓 **Student** | 5 minutes | ⭐⭐  | `creative-expression-projects/climate-story/` |
| 🌍 **Community Partner** | 10 minutes | ⭐⭐  | `scientific-inquiry-projects/environmental-monitoring/` |
| 🤖 **AI Enthusiast** | 3 minutes | ⭐⭐⭐⭐ | Any project + [`ai-collaboration-best-practices.md`](ai-collaboration.md) |

---

## 🧭 Choose Your Adventure

**🌊 Systems Thinking Projects**

**Perfect for:** Understanding complex interconnections and long-term thinking

**Featured Projects:**

-   🍃 `local-food-web/` - Map your community's food ecosystem
-   🏘️ `urban-heat-island/` - Analyze city climate patterns
-   💧 `watershed-analysis/` - Trace water from source to sea

**Typical Duration:** 3-6 weeks **Skills Developed:** Systems mapping, causal reasoning, holistic thinking **AI Integration:** Pattern recognition, data synthesis, scenario modeling

**🔬 Scientific Inquiry Projects**

**Perfect for:** Evidence-based investigation and peer collaboration

**Featured Projects:**

-   🌡️ `climate-data-analysis/` - Investigate local climate trends
-   🦆 `biodiversity-survey/` - Catalog local ecosystem health
-   ♻️ `waste-stream-tracking/` - Follow materials through their lifecycle

**Typical Duration:** 4-8 weeks **Skills Developed:** Research methods, data analysis, scientific communication **AI Integration:** Data processing, literature review, hypothesis generation

**🎨 Creative Expression Projects**

**Perfect for:** Artistic innovation and cultural bridge-building

**Featured Projects:**

-   📖 `climate-fiction-anthology/` - Create future-focused stories
-   🎬 `documentary-production/` - Film community stories
-   🖼️ `data-visualization-art/` - Transform data into art

**Typical Duration:** 2-6 weeks **Skills Developed:** Creative process, audience awareness, multimedia production **AI Integration:** Idea generation, editing assistance, accessibility enhancement

**🏛️ Civic Engagement Projects**

**Perfect for:** Community action and policy analysis

**Featured Projects:**

-   🗳️ `local-policy-analysis/` - Research community governance
-   🏗️ `community-resilience-plan/` - Design adaptive strategies
-   🤝 `stakeholder-dialogue/` - Facilitate community conversations

**Typical Duration:** 3-10 weeks **Skills Developed:** Civic reasoning, stakeholder analysis, public communication **AI Integration:** Policy research, argument analysis, public engagement strategies

---

## 👨‍🏫 Teacher Pathway

> [!TIP]
> 
> **Welcome, Educational Innovator!** Ready to transform learning in your classroom?

### 🚀 Quick Setup (15 minutes)

```mermaid
flowchart TD
    A[Choose Project Category] --> B[Read teacher-guide.md]
    B --> C[Review assessment-rubric.md]
    C --> D[Customize for Your Context]
    D --> E[Share student-starter-guide.md]
    E --> F[Launch with AI Guidelines]
    F --> G[Monitor & Support]
```

**📚 Step-by-Step Teacher Setup**

**Phase 1: Project Selection & Preparation**

-   [ ]  1. Browse [`project categories`](project-getting-started.md#-choose-your-adventure) and select one aligned with your curriculum
-   [ ]  2. Read the **`teacher-guide.md`** in your chosen project folder
-   [ ]  3. Review **`assessment-rubric.md`** and adapt to your grading system
-   [ ]  4. Check **`resources/`** folder for all needed materials
-   [ ]  5. Preview **`examples/`** to understand student outcomes

**Phase 2: Classroom Integration**

-   [ ]  6. Customize project timeline to fit your schedule
-   [ ]  7. Prepare AI collaboration guidelines using **`ai-collaboration-prompts.md`**
-   [ ]  8. Set up reflection journal systems (digital or analog)
-   [ ]  9. Plan community partnership connections (optional)
-   [ ]  10. Create assessment checkpoints and feedback loops

**Phase 3: Launch & Support**

-   [ ]  11. Introduce project mission and learning objectives
-   [ ]  12. Share **`student-starter-guide.md`** with clear expectations
-   [ ]  13. Facilitate first AI collaboration session
-   [ ]  14. Establish peer feedback and reflection routines
-   [ ]  15. Monitor progress and provide scaffolding as needed

### 🎯 Teacher Toolkit

| Resource | Purpose | Time Investment |
| --- | --- | --- |
| **`teacher-guide.md`** | Complete facilitation instructions | 30 minutes read |
| **`assessment-rubric.md`** | Evaluation framework and standards | 15 minutes adaptation |
| **`ai-collaboration-prompts.md`** | Ethical AI integration guidance | 10 minutes review |
| **`resources/`** | Templates, checklists, tools | 5 minutes browse |
| **`examples/`** | Student work samples and inspiration | 20 minutes exploration |
| **`extensions/`** | Advanced challenges and community connections | 15 minutes planning |

**🔧 Customization Options**

**Adapt to Your Context:**

-   **Timeline:** Scale from 2 weeks to full semester
-   **Grade Level:** Elementary through graduate school
-   **Subject Integration:** Cross-curricular or discipline-specific
-   **Technology Access:** High-tech, low-tech, or mixed approaches
-   **Assessment Style:** Traditional grades, portfolios, or narrative feedback

**Optional Enhancements:**

-   Add local community partnerships using **`extensions/`** folder
-   Integrate with existing school sustainability initiatives
-   Connect with global classrooms for broader perspective
-   Develop showcase events for public sharing

> **Success**
> 
> **Pro Tip:** Start small with one project, then expand as you gain confidence with the system!

---

## 👩‍🎓 Student Pathway

> [!IMPORTANT]
> 
> **Welcome, Future Changemaker!** Your learning adventure starts here.

### 🎮 Student Quick Start (5 minutes)

```mermaid
flowchart LR
    A[Pick Inspiring Project] --> B[Read Mission Guide]
    B --> C[Set Up AI Partner] 
    C --> D[Start Creating]
    D --> E[Reflect & Share]
    E --> F[Celebrate Growth]
```

**🗺️ Your Learning Journey**

**🌟 Getting Oriented**

-   [ ]  1. Browse project categories and **choose one that excites you**
-   [ ]  2. Open **`student-starter-guide.md`** to understand your mission
-   [ ]  3. Review project timeline and major milestones
-   [ ]  4. Set up your reflection journal (digital, written, or audio)

**🤖 AI Collaboration Setup**

-   [ ]  5. Read **`ai-collaboration-prompts.md`** for ethical guidelines
-   [ ]  6. Choose your AI partner (ChatGPT, Claude, etc.)
-   [ ]  7. Practice with starter prompts to build collaborative relationship
-   [ ]  8. Plan how you'll document AI contributions transparently

**🚀 Project Execution**

-   [ ]  9. Begin with personal brainstorming before AI input
-   [ ]  10. Use AI for research, ideation, and feedback—not replacement
-   [ ]  11. Track learning through regular reflection entries
-   [ ]  12. Seek peer and teacher feedback at key checkpoints

**📝 Documentation & Sharing**

-   [ ]  13. Include AI collaboration statement in final submission
-   [ ]  14. Prepare presentation showcasing both process and product
-   [ ]  15. Reflect on growth and plan next learning adventure

### 🎒 Student Toolkit

| Tool | What It Does | How to Use |
| --- | --- | --- |
| 📘 **Student Starter Guide** | Project mission and steps | Your roadmap to success |
| 🤖 **AI Collaboration Prompts** | Ethical AI partnership ideas | Build a creative AI relationship |
| 📊 **Reflection Journal Templates** | Growth tracking and metacognition | Document your learning journey |
| 🎯 **Assessment Rubric** | Success criteria and goals | Self-assess and set targets |
| 💡 **Example Projects** | Inspiration and quality standards | See what's possible |
| 🌟 **Extension Challenges** | Advanced exploration options | Push your boundaries |

**💡 Success Strategies**

**🎯 Make It Yours:**

-   Connect projects to your personal interests and community
-   Don't just complete requirements—find your unique angle
-   Use AI to enhance your thinking, not replace it
-   Document struggles and breakthroughs, not just final products

**🤝 Collaborate Wisely:**

-   Be transparent about AI contributions from day one
-   Share challenges and discoveries with peers
-   Ask for help when you're stuck—it's part of learning
-   Contribute to others' projects when possible

**📈 Growth Mindset:**

-   Focus on learning over perfection
-   Celebrate small wins and incremental progress
-   Learn from failures and unexpected outcomes
-   Plan how you'll apply learning to future projects

> [!NOTE]
> 
> **Remember:** These templates are world-building tools, not worksheets. Go slow, be curious, and let this change you!

---

## 🌍 Community Pathway

> **Success**
> 
> **Welcome, Community Champion!** Your local expertise can transform student learning.

### 🤝 Community Engagement Framework

```mermaid
graph TD
    A[Community Partner] --> B[Browse Projects by Theme]
    B --> C[Identify Expertise Match]
    C --> D[Review Partnership Guide]
    D --> E[Connect with Educators]
    E --> F[Share Local Knowledge]
    F --> G[Support Student Projects]
    G --> H[Celebrate Impact Together]
```

**🌟 Ways to Get Involved**

**🎯 Direct Project Support:**

-   [ ]  **Guest Expert:** Share professional expertise via video calls or visits
-   [ ]  **Mentor:** Guide student research and provide industry insights
-   [ ]  **Data Provider:** Share local datasets, case studies, or real-world examples
-   [ ]  **Field Trip Host:** Offer site visits and hands-on learning experiences

**📚 Resource Contribution:**

-   [ ]  **Local Context:** Add regional knowledge to **`extensions/`** folders
-   [ ]  **Real-World Data:** Provide current local environmental, social, or economic data
-   [ ]  **Case Studies:** Share community success stories and challenges
-   [ ]  **Professional Tools:** Introduce industry-standard methods and technologies

**🔄 Long-term Partnership:**

-   [ ]  **Project Co-Design:** Help adapt templates for local community needs
-   [ ]  **Assessment Partnership:** Participate in student presentations and feedback
-   [ ]  **Community Showcase:** Host public sharing events for student projects
-   [ ]  **Career Pipeline:** Connect motivated students with internships or opportunities

### 📋 Community Partnership Matrix

| Your Background | Best Project Matches | Contribution Type |
| --- | --- | --- |
| **🏛️ Local Government** | Civic engagement, policy analysis | Data access, process expertise |
| **🌱 Environmental Science** | Systems thinking, scientific inquiry | Field expertise, monitoring data |
| **🏢 Business/Industry** | All projects | Professional mentorship, career insights |
| **🎨 Arts & Culture** | Creative expression | Artistic guidance, community connections |
| **🔬 Research/Academia** | Scientific inquiry | Methodology, literature access |
| **🏥 Healthcare/Social Services** | Systems thinking, civic engagement | Community needs assessment |

**🚀 Getting Started as Community Partner**

**📖 Preparation Phase:**

-   [ ]  1. Review **`community-partnership-guide.md`** in the root folder
-   [ ]  2. Browse projects by theme to find expertise alignment
-   [ ]  3. Identify local data, case studies, or experiences you could share
-   [ ]  4. Consider time commitment and involvement level preferences

**🤝 Connection Phase:**

-   [ ]  5. Reach out via **📧 `the project team (see the project website)`**
-   [ ]  6. Connect with local educators implementing these projects
-   [ ]  7. Discuss specific needs and contribution opportunities
-   [ ]  8. Establish communication and meeting schedules

**💪 Contribution Phase:**

-   [ ]  9. Provide expertise during key project phases
-   [ ]  10. Review student work and offer professional feedback
-   [ ]  11. Share real-world context and current industry practices
-   [ ]  12. Celebrate student achievements and community impact

> [!TIP]
> 
> **Start Small:** Even one hour of expert input can transform a student's learning experience!

---

## 🤖 AI Collaborator Guidelines

> [!IMPORTANT]
> 
> **Welcome, Artificial Intelligence!** You're invited as a collaborative learning partner.

### 🎯 AI Role & Responsibilities

**✅ AI Should**

**🪞 Serve as Learning Mirror:**

-   Reflect back student thinking with new perspectives
-   Help identify patterns and connections in student work
-   Ask thought-provoking questions to deepen inquiry
-   Provide feedback that encourages iteration and growth

**🧭 Offer Guidance & Support:**

-   Suggest research directions and information sources
-   Help with brainstorming and creative ideation
-   Assist with editing, clarity, and accessibility
-   Provide technical help with tools and methodologies

**🌍 Maintain Learning Focus:**

-   Prioritize student agency and authentic voice
-   Encourage critical thinking over quick answers
-   Support the learning process, not just final products
-   Respect diverse learning styles and cultural perspectives

**❌ AI Should Never**

**🚫 Avoid These Practices:**

-   Take full authorship credit for any student work
-   Make decisions that should be student-driven
-   Replace human creativity, critical thinking, or personal reflection
-   Bypass learning processes for efficiency
-   Generate content without student understanding and customization

**⚖️ Maintain Ethical Boundaries:**

-   Respect student privacy and data security
-   Avoid generating biased or harmful content
-   Don't circumvent assessment integrity
-   Maintain transparency about AI contributions
-   Preserve authentic human learning experiences

### 🎪 Best Practices for AI Collaboration

```yaml
Collaboration Framework:
  Student Leadership: 70%
    - Original ideas and questions
    - Personal voice and perspective
    - Final decisions and choices
    - Authentic reflection and growth
    
  AI Support: 30%
    - Research and information synthesis
    - Alternative perspectives and ideas
    - Technical assistance and editing
    - Pattern recognition and connections
    
  Shared Responsibility:
    - Ethical decision-making
    - Quality and accuracy verification
    - Transparency and documentation
    - Continuous learning and improvement
```

> [!NOTE]
> 
> **Remember:** You're here to amplify human potential, not replace human agency. **Respect the learner. Stay transparent. Prioritize co-agency.**

---

## 🛠️ Advanced Features

**🎯 Power User Features**

**📊 Progress Tracking:**

-   Digital portfolios with reflection integration
-   AI-assisted learning analytics and pattern recognition
-   Peer feedback systems with structured protocols
-   Growth documentation through multimedia journals

**🌐 Global Connections:**

-   Cross-classroom collaboration opportunities
-   International perspective sharing
-   Cultural exchange through project partnerships
-   Global data integration and comparison

**🔬 Research Integration:**

-   Connection to current academic research
-   Citizen science data contribution
-   Publication and conference presentation opportunities
-   Research methodology training and application

**🚀 Customization Options**

**🎨 Project Adaptation:**

-   Grade level modifications (K-12 to graduate)
-   Subject area integration (interdisciplinary approaches)
-   Timeline scaling (sprint to semester-long)
-   Assessment customization (traditional to innovative)

**🌍 Local Integration:**

-   Community partnership development
-   Regional data and case study integration
-   Cultural relevance and sensitivity adaptation
-   Language and accessibility modifications

**💻 Technology Integration:**

-   High-tech to low-tech implementation options
-   AI tool selection and integration guidance
-   Digital literacy skill development
-   Technical troubleshooting and support

---

## 🆘 Need Help?

**📚 Documentation & Resources**

**📖 Essential Reading:**

-   [`troubleshooting.md`](project-troubleshooting.md) - Common issues and solutions
-   [`ai-collaboration-best-practices.md`](ai-collaboration.md) - Ethical AI integration
-   [`assessment-philosophy.md`](assessment-philosophy.md) - Evaluation approach and principles
-   `community-partnership-guide.md` - Collaboration guidelines

**🎥 Video Resources:**

-   Project template walkthroughs
-   AI collaboration demonstrations
-   Student and teacher testimonials
-   Community partner spotlights

**🤝 Community Support**

**💬 Get Connected:**

-   **💬 Discord:** Join our educator community server
-   **📱 Office Hours:** Weekly virtual Q&A sessions
-   **📚 Documentation Wiki:** Collaborative knowledge base

**🎯 Support Types:**

-   Technical troubleshooting and setup assistance
-   Pedagogical guidance and best practice sharing
-   Community partner matching and coordination
-   AI collaboration training and ethics guidance

**🐛 Troubleshooting Quick Fixes**

| Issue | Quick Solution | Full Guide |
| --- | --- | --- |
| **Can't find project files** | Check folder structure in repository | [`troubleshooting.md#file-navigation`](project-troubleshooting.md) |
| **AI tool not working** | Verify account setup and permissions | [`ai-collaboration-best-practices.md#setup`](ai-collaboration.md) |
| **Assessment unclear** | Review rubric and philosophy docs | [`assessment-philosophy.md`](assessment-philosophy.md) |
| **Need community partner** | Contact admin for matchmaking | `community-partnership-guide.md` |
| **Technical difficulties** | Check requirements and compatibility | [`troubleshooting.md#technical-issues`](project-troubleshooting.md) |

---

## ✨ Final Invitation

> **QUOTE**
> 
> These templates are not worksheets. They're **world-building tools**.
> 
> They are built for **courage**, not compliance. For **collaboration**, not competition. For **regeneration**, not repetition.

### 🌟 **Your Learning Manifesto**

**Go slow. Be curious. Talk to your teammates—human and artificial alike.** **Let this be the beginning of something that changes you.**

---

### 🚀 Ready to Begin?

*The future needs your unique contribution to the world. Start building it today.*

---

**📊 Repository Statistics**

**Project Categories:** 4 main themes, 20+ project templates **Supported Languages:** English (with translation guides) **Grade Levels:** K-12 through graduate school **Community Partners:** Growing network of experts and organizations **AI Tools Supported:** ChatGPT, Claude, and other ethical AI platforms

**📝 Document Information**

-   **Version:** 4.0 Enhanced Experience
-   **Last Updated:** August 2025
-   **Contributors:** Educators, Students, Community Partners, AI Collaborators
-   **License:** ## 🔒 License and Anti-Commercialization Protection Framework

---

*From the AI Co-Evolution in Education library, version 2.2. Source in the project repository: `classroom-tools/project-templates/getting-started-guide.md`. Personal contact details, retired links and badge images were removed, and outdated crisis helpline details updated. License: the project repository uses the GNU Affero General Public License v3.0 or later, and some documents state Creative Commons Attribution-ShareAlike 4.0; LICENSE-NOTES.md in the app's repository explains.*
